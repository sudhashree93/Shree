const routes = {
  // '/': 'Home'
  '/dashboard': 'Dashboard'

};
export default routes;
