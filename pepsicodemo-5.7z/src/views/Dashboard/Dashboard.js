import React, {Component} from "react";
import Tableau from 'tableau-api';
import {Switch, Route, Redirect} from 'react-router-dom';
import Header from '../../components/Header/';
import Sidebar from '../../components/Sidebar/';
var downFlag;
var countryVal;
var stateVal;
var viz;
var url;
var country1;
var state1;
var opt;
var div1;
var divVal;
var reg1;
var regVal;
var mrkt1;
var mrktVal;
var grade1;
var gradeVal;
var timef1;
var timefVal;
var timer1;
var timerVal;
var storenum1;
var strvolVal;
var storenumVal;
var job1;
var jobVal;
var timec1;
var timecVal;
var dept1;
var deptVal;
var division1;
var divisionVal;
var compVal;
var histVal;
var pftVal;
var resetVal;
var comprVal;
var startDate;
var endDate;
var showCmp;
 var prevOpt={};
 var measureVal;
 var that;
 var count=0;
 var paramName,paramValue,inputReg,inputMkt,sortReg,sortMkt,tbReg,tbMkt,divExeVal,regExeVal,filterName,filterValue;
var jobcVal;

class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state  = {viz:{},filterData1:{}};
    this.onData1Changed = this.onData1Changed.bind(this);
    this.onData2Changed = this.onData2Changed.bind(this);
  this.onScrChanged = this.onScrChanged.bind(this);
    this.applyFilter = this.applyFilter.bind(this);
  }
  
 convertVal(val){
 if(val != undefined){
 var abc=[];
 
for(var i=0;i<val.length;i++){

 abc.push(val[i].value);
}

var index = abc.indexOf("All");
if (index >= 0) {
  abc.splice( index, 1 );
}
return abc;
}
}

  onData1Changed(newData1){

 
this.setState({downFlag:false});
    divVal =this.convertVal(newData1.divVal);

    divisionVal =this.convertVal(newData1.divisionVal);

    regVal =this.convertVal(newData1.regVal);


    mrktVal =this.convertVal(newData1.mrktVal);

    storenumVal =this.convertVal(newData1.storenumVal);
  
  strvolVal =this.convertVal(newData1.strvolVal);

    deptVal =this.convertVal(newData1.deptVal);

    jobVal =this.convertVal(newData1.jobVal);

    timecVal =this.convertVal(newData1.timecVal);

    timerVal =this.convertVal(newData1.timerVal);
     timefVal= this.convertVal(newData1.timefVal);
     measureVal=newData1.measureVal;

    gradeVal=this.convertVal(newData1.gradeVal);
  pftVal=this.convertVal(newData1.pftVal);
  resetVal= newData1.reset;
  comprVal=newData1.timeView ? newData1.timeView : "";
  startDate=newData1.startDate ? newData1.startDate : "";
  endDate=newData1.endDate ?newData1.endDate:"";
  jobcVal=this.convertVal(newData1.jobcVal);

  if(resetVal=="yes"){
   divVal ="";

    divisionVal ="";

    regVal ="";


    mrktVal ="";

    storenumVal ="";
  
  strvolVal ="";

    deptVal ="";

    jobVal ="";

    timecVal ="";

    timerVal ="";
     timefVal= "";
jobcVal="";
    
    gradeVal="";
  pftVal="";
  comprVal="";
  startDate='';
  endDate="";
  measureVal="";
  }
  this.setState({showCmp:false});

if(newData1 != undefined && newData1 != "" && newData1 =="refresh"){

this.setState({isRefresh :"Y"});

}else{
this.setState({isRefresh :"N"});
}

if(newData1 != undefined && newData1 != "" && newData1 =="home"){

url="https://tableau.wal-mart.com/t/WalmartHR/views/WalmartUSLandingPage/LandingPage?:embed=y&:display_count=no&:showShareOptions=true&:showVizHome=no";
opt="home";
}


  this.initTableau();
}


isNullOrUndefined(name) {
 if ( name == null || name === '' || name === undefined ) {
	
	return false;
 }else{
 
	 return true;
	 }
 
}


applyFilter(dwnOpt){
  if(viz){
    if(dwnOpt=="wrkbook"){
      viz.showDownloadWorkbookDialog();
      
    }else if(dwnOpt=="pdf"){
      viz.showExportPDFDialog();
    }else if(dwnOpt=="cross"){
      viz.showExportCrossTabDialog();
    }else if(dwnOpt=="data1"){
      viz.showExportDataDialog();
    }else if(dwnOpt=="img1"){
      viz.showExportImageDialog();
    }else if(dwnOpt=="shr"){
      viz.showShareDialog();
    }else if(dwnOpt=="datadwn" && this.isNullOrUndefined(that.state.ddFilval) && this.isNullOrUndefined(that.state.ddFilname) ){
       that.setState({downFlag:true});
    }else{
       that.setState({downFlag:false});
    }

  }

}

onScrChanged(data){
if(data =="full"){
this.setState({fullScr:true});
}else{
this.setState({fullScr:false});
}
}
onData2Changed(newData2){

this.setState({downFlag:false});
  opt = newData2.value;
  if(opt=="cs"){
       
         url="https://10ay.online.tableau.com/t/itteam/views/Headcount-CurrentSummary/CurrentSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
     this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
             compVal="";
         histVal="";
         comprVal="";
        //  startDate="";
        //  endDate="";
      }else if(opt=="cd"){
       
      url="https://10ay.online.tableau.com/t/itteam/views/Headcount-CurrentDetail/CurrentDetail?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
    this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
      }else if(opt=="trnd"){
       
        url="https://10ay.online.tableau.com/t/itteam/views/Headcount-Trend143/HeadCountTrend?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
    this.setState({compEn: false,histEn:true,comprEn:true,showCmp :true}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         
      }else if(opt=="prd"){
           
         url="https://10ay.online.tableau.com/t/itteam/views/Headcount-PeriodtoPeriod143/PeriodtoPeriod?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
        this.setState({compEn: true,histEn:false,comprEn:true,showCmp :true}, function () {
               console.log(this.state.compEn);
             }); 
             histVal=""; 
            
      }else if(opt=="csm"){
    url="https://10ay.online.tableau.com/t/itteam/views/WalmartUSHeadcount-CurrentSummary/CurrentSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }else if(opt=="trndm"){
    url="https://10ay.online.tableau.com/t/itteam/views/Headcount-Trend143/HeadCountTrend?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
        this.setState({compEn: false,histEn:true,comprEn:true,showCmp :true}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
       
      }else if(opt=="prdm"){
    url="https://10ay.online.tableau.com/t/itteam/views/Headcount-PeriodtoPeriod143/PeriodtoPeriod?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
        this.setState({compEn: true,histEn:false,comprEn:true,showCmp :true}, function () {
               console.log(this.state.compEn);
             }); 
             histVal=""; 
            
      }else if(opt=="csr"){
    url="https://10ay.online.tableau.com/t/itteam/views/WalmartUSHeadcount-CurrentSummary/CurrentSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }else if(opt=="ch"){
    url="https://tableau.wal-mart.com/t/WalmartHR/views/WalmartUSPerformance-CurrentHourly/CurrentHourly?:embed=y&:showShareOptions=true&:display_count=no&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }else if(opt=="cm"){
    url="https://tableau.wal-mart.com/t/WalmartHR/views/WalmartUSPerformance-CurrentManagement/CurrentManagement?:embed=y&:showShareOptions=true&:display_count=no&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }
     else if(opt=="cst"){
    url="https://10ay.online.tableau.com/t/itteam/views/WalmartUSHeadcount-CurrentSummary/CurrentSummary?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
         comprVal="";
        //  startDate="";
        //  endDate="";
       }
       else if(opt=="kpi"){
    url="https://tableau.wal-mart.com/t/WalmartHR/views/WalmartUSLandingPage/LandingPage?:embed=y&:display_count=no&:showShareOptions=true&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }
        else if(opt=="exe"){
    url="https://10ay.online.tableau.com/t/itteam/views/BlankDashboard-Logo/Dashboard1?iframeSizedToWindow=true&:embed=y&:display_count=no&:showAppBanner=false&:showVizHome=no";
    
         this.setState({compEn: false,histEn:false,comprEn:false, isHome :true,measure:true}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }

         else if(opt=="cmp"){
    url="https://10ay.online.tableau.com/t/itteam/views/BlankDashboard-Logo/Dashboard1?iframeSizedToWindow=true&:embed=y&:display_count=no&:showAppBanner=false&:showVizHome=no";    
         this.setState({compEn: false,histEn:false,comprEn:false}, function () {
               console.log(this.state.compEn);
             }); 
         compVal="";
         histVal="";
          comprVal="";
        //  startDate="";
        //  endDate="";
       }
       if(opt != "exe"){
            this.setState({ isHome :true,measure:false}, function () {
               console.log(this.state.isHome);
             }); 

       }
       if(opt != "undefined"){
      this.initTableau();
       }
    }

    initTableau() {
      this.setState({downFlag:false});
      that=this;
  
  if(opt!=""){
  sessionStorage.opt=opt;
  }
      if(url=="" || url==undefined){
         this.setState({ measure:false,isHome:true}, function () {
               console.log(this.state.isHome);
             }); 
      url="https://tableau.wal-mart.com/t/WalmartHR/views/WalmartUSLandingPage/LandingPage?:embed=y&:display_count=no&:showShareOptions=true&:showVizHome=no";
     }
   
   if(this.state.fullScr == true){
    var height1 = '650px';
   }else{
   var height1='650px';
   }

     const options = {
      'height': '100%',
      'width': '100%',
      'hideToolbar':  true,
      'BUSINESS_UNIT' : divVal ? divVal : "",
      "Division" : divisionVal ? divisionVal:"",
      'REGION_NAME' : regVal ? regVal : "",
      'MARKET_AREA_NAME' : mrktVal ? mrktVal : "",
      'STORE_NBR' : storenumVal ? storenumVal :"",
      'Store_Volume' : strvolVal ? strvolVal:"",
      'Department':deptVal ? deptVal :"",
      'Grade_Level_grp' :gradeVal ? gradeVal :"",
      'Time in Facility Bucket' : timefVal ? timefVal :"",
      'Time in Role Bucket ' : timerVal ? timerVal :"",
      'Job_Family': jobVal ? jobVal :"",
      'Time in Company Bucket':timecVal ? timecVal :"",
      'PT_FT_Temp': pftVal ? pftVal:"",
      'PPE':histVal?histVal:"",
      "Start Date" : startDate ? startDate :"",
      "End Date" : endDate ? endDate :"",
      "Time View" : comprVal ? comprVal :"",
      "Measure":measureVal?measureVal:"",
      "Input Reg": inputReg ?inputReg:"",
      "Input Mkt":inputMkt ?inputMkt:"",
      "Sort Mkt":sortReg ?sortReg:"",
      "Sort Reg":sortMkt ?sortMkt:"",
      "Top / Bottom Mkt":tbReg ?tbReg:"",
      "Top / Bottom Reg":tbMkt ?tbMkt:"",
      "DIVISION_EXE":divExeVal ? divExeVal :"",
      "REGION_EXE":regExeVal?regExeVal:"",
      "JOB_CODE":jobcVal?jobcVal:"",
            onFirstInteractive: () => {

             if(opt=="prd" || opt=="trnd" || opt=="trndm" || opt=="prdm"){
               if(startDate !="" && endDate !="" && startDate !=undefined && endDate !=undefined){
              viz.getWorkbook().changeParameterValueAsync("Start Date", startDate).then(
                function (){ console.log('Parameter set');}
                );
                viz.getWorkbook().changeParameterValueAsync("End Date", endDate).then(
                function (){ console.log('Parameter set');}
                );
             }
             }
             if(opt=="exe"){
             viz.addEventListener(tableau.TableauEventName.PARAMETER_VALUE_CHANGE, that.onParameterValueChange);
             viz.addEventListener(tableau.TableauEventName.FILTER_CHANGE, that.onFilterValueChange);
             count=0;
             }
             if(opt=="cs"){

               this.listenToMarksSelection();
             }

           
           }

            };
          
           if(opt == "cmp"){
              var key_cmp = Object.keys(options);
            delete options['Measure'];
           }
            var keys = Object.keys(options);
            for(var i=0; i<keys.length;i++){

                  if(options[keys[i]] == ""){

                    delete options[keys[i]];
                  }
            }
            var opt_fil={};
             opt_fil=Object.assign({},options);
             var exe_opt=['Grade_Level_grp','Job_Family','PT_FT_Temp'];
            var fil_key = [ 'height','width','hideToolbar','onFirstInteractive'];
            for(var i=0; i<fil_key.length;i++){


                    delete opt_fil[fil_key[i]];
            }

                 delete opt_fil['Measure'];
                //  delete opt_fil['Start Date'];
                //  delete opt_fil['End Date'];
                 delete opt_fil['Time View'];
                 delete opt_fil['Input Reg'];
                 delete opt_fil['Input Mkt'];
                 delete opt_fil['Sort Mkt'];
                 delete opt_fil['Sort Reg'];
                 delete opt_fil['Top / Bottom Mkt'];
                 delete opt_fil['Top / Bottom Reg'];
                 delete opt_fil['DIVISION_EXE'];
                 delete opt_fil['REGION_EXE'];

                
            console.log(opt_fil);
             var optKey = Object.keys(opt_fil);
            if(opt !="trnd" && opt!="prd" && opt !="trndm" && opt!="prdm" ){
              delete opt_fil['Start Date'];
              delete opt_fil['End Date'];
            }
             optKey = Object.keys(opt_fil);
            //  if(optKey.length > 0){
            this.setState({filterSel:opt_fil});
            //  }

            //  if(optKey.length == 0){
            // this.setState({filterSel:[]});
            //  }
            
            if(viz){
              viz.dispose();
            }

            viz = new tableau.Viz(this.container, url, options);
            this.setState({
              viz:viz
            })

          } 

           listenToMarksSelection() {
            that=this;
            viz.addEventListener(tableau.TableauEventName.MARKS_SELECTION, this.onMarksSelection);
        }

         onMarksSelection(marksEvent) {
            return marksEvent.getMarksAsync().then(that.reportSelectedMarks);
        }

         reportSelectedMarks(marks) {
           
            
            for (var markIndex = 0; markIndex < marks.length; markIndex++) {
                var pairs = marks[markIndex].getPairs();
                that.setState({ddFilname:pairs[0].fieldName,ddFilval:pairs[0].formattedValue,downFlag:false});
               
            }
         }


          onParameterValueChange(e){
            e.getParameterAsync().then(function(param){
            
                paramName  = param.getName();
                paramValue =param.getCurrentValue().formattedValue;

                if(paramName=="Input Reg"){

                  inputReg =paramValue;
                }
                if(paramName=="Input Mkt"){

                  inputMkt =paramValue;

                }
                if(paramName=="Sort Mkt"){

                  sortReg =paramValue;

                }
                if(paramName=="Sort Reg"){

                  sortMkt =paramValue;

                }
                if(paramName=="Top / Bottom Mkt"){

                  tbReg =paramValue;

                }
                if(paramName=="Top / Bottom Reg"){

                  tbMkt =paramValue;

                }


                
            });
          }

            onFilterValueChange(e){
            e.getFilterAsync().then(function(filter1){
                if(count==0){
                filterName  = filter1.getFieldName();
                filterValue =filter1.getAppliedValues();
                 var filtVal=[];
                

                for(var i=0; i<filterValue.length;i++){

                  filtVal.push(filterValue[i].formattedValue);

                }

                if(filterName=="DIVISION_EXE"){

                  divExeVal =filtVal;
                }
                if(filterName=="REGION_EXE"){

                  regExeVal =filtVal;

                }
                }
               

            });
          }

          clickfun(){
            
            document.getElementById("dropdownMenuHeadcount").style.display = 'none';
            document.getElementById("dropdownMenuRecruiting").style.display = 'none';
            document.getElementById("dropdownMenuMovement").style.display = 'none';
            document.getElementById("dropdownMenuPerformance").style.display = 'none';
            document.getElementById("dropdownMenuTalent").style.display = 'none';
          }


          render() {

            return (
              <div>
                <Header onData2Changed={this.onData2Changed} onScrChanged={this.onScrChanged} onData1Changed={this.onData1Changed} applyFilter={this.applyFilter}/>
                <div className="app-body" onClick={()=>this.clickfun()}>
                  <Sidebar  onData1Changed={this.onData1Changed}  measure={this.state.measure} 
                  isRefresh={this.state.isRefresh} comprEn={this.state.comprEn} isHome ={this.state.isHome}   
                  showCmp={this.state.showCmp} downFlag={this.state.downFlag} filval={this.state.ddFilval}
                  filname={this.state.ddFilname} filterSel={this.state.filterSel} />
                  <div id="right-side-wrapper">
                    <div className="body-bg-wrapper">
                      <div className="body-bg">
                        <div className="box sixteen-nine">
                          <div className="content">
                            <div style={{height:'100%'}} ref={c => (this.container=c)}></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              )
            }
componentDidMount(){
if(sessionStorage.opt !=""){
  opt = sessionStorage.opt;
  }
  this.initTableau();
}
         
          }

          export default Dashboard;
