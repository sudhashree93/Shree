import React, {Component} from 'react';
import {Switch, Route, Redirect} from 'react-router-dom';
import Header from '../../components/Header/';
import Sidebar from '../../components/Sidebar/';
import Footer from '../../components/Footer/';
import Dashboard from '../../views/Dashboard/';


class Full extends Component {

render() {
    return (
      <div className="app" >
       <Dashboard />
        <Footer />
      </div>
    );
  }
}

export default Full;
