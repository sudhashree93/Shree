import React, {Component} from 'react';
import {NavLink} from 'react-router-dom';
import SelectField from 'material-ui/SelectField';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import RaisedButton  from 'material-ui/RaisedButton';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import MenuItem from 'material-ui/MenuItem';
import equal  from 'equals';
import SuperSelectField from 'material-ui-superselectfield';
import axios from 'axios';
import Dashboard from  '../../views/Dashboard/';
import Checkbox from 'material-ui/Checkbox';
import TextField from 'material-ui/TextField';
import $ from 'jquery';
import IconButton from 'material-ui/IconButton';
import ToggleDisplay from 'react-toggle-display';




var that;
var counter=0;
var values =[];
var count=0;
var prevValue;
var yearVal=[];
var qtrId=0;
var startDate;
var endDate;
var yeardata=[];
var initYear=[];
var timeCount=0;
var actualVal=[];
var countEle =0;
var s_flag="";
var p_flag="";
var filterDef;
var measureVal=[];
var saveval="";
var prefFlag=false;
var prefName="";
var dwnFl="";
var options={};
const styles = {
  customWidth: {
     width: '80%',
   fontSize:'12px',
   marginTop: '-13px'
  },
  
};

const styles1 = {
  block: {
    backgroundColor:"#76b9e6",
    marginTop: "3%",
    color: "white",
    
  },
  checkbox: {
    marginBottom: 1,
    
  },
};


class FilterEle extends React.Component {
  render() {
    return ( <span id="filterReset"> <br></br><i className="fa fa-filter" aria-hidden="true"><span> <i className="fa fa-times filterOpt"></i> Reset all</span></i> </span>);
  }
}

class FilterIcon extends React.Component {
  render() {
    return ( <span id="filterReset1"> <br></br><i className="fa fa-filter" aria-hidden="true"><span> <i className="fa fa-times filterOpt"></i></span></i> </span>);
  }
}

class Sidebar extends Component {

 constructor(props) {
  super(props);


  this.state  = {

   reg :[],
   div:[],
   mrkt:[],
   store:[],
   grade:[],
   timer:[],
   timef:[],
   job:[],
   timec:[],
   storenum:[],
   division:[],
   dept:[],
   strvol:[],
   org:[''],
   orgVal:[],
   currSel : false,
   currSel1:true,
   filterVisible: false,
   showDivbox:true,
   showRegbox :true,
   showMarktbox : true,
   showStorebox:true,
   showGradebox:true,
   showTimefbox:true,
   showTimerbox:true,
   showJobbox:true,
   showTimecbox:true,
   showDivisionbox:true,
   showDeptbox:true,
   abc:[],
   stayOpen : false,
   gradeVal:[],
   storenumVal:[],
   deptVal:[],
   divVal:[],
   divisionVal:[],
   regVal:[],
   mrktVal:[],
   jobVal:[],
   timecVal:[],
   timefVal:[],
   timerVal:[],
   strvolVal:[],
   ifClickedOpt:false,
   ifClickedOpt1:false,
   ifClickedOpt2:false,
   ifClickedOpt3:false,
   comprEn:false,
   histEn:false,
   pft:[],
   pftVal:[],
   jobc:[],
   jobcVal:[],
   comprVal:[],
   displayopt:false,
   p2p1:[],
   p2p2:[],
   p2p3:[],
   p2p4:[],
   p2p1_1:[],p2p1_2:[],p2p1_3:[], p2p2_1:[],p2p2_2:[],p2p2_3:[], p2p3_1:[],p2p3_2:[],p2p3_3:[], p2p4_1:[],p2p4_2:[],p2p4_3:[],
   qtr:[],
   qtr1:[],
   qtr2:[],
   qtr3:[],
   bgColor:"white",
   yearDis:true,
   qtrDis:true,
   p2pDis:true,
   applyDisabled:true,
   isHome :false,
   checked1 :true,
    checked2 :true,
     checked3 :true,
      checked4 :true,
       checked5 :true,
        checked6 :true,
        checked7:true,
         checked :true,
         checkedA:true,
         measure :true,
         filterSel:['Filters Selected - All'],
         filterCnt :[0],
         isCollapse:false,
         showCombo:false,
         prefNames:[],
         showfil:false,
         defaultVal:[],
         showPref:false,
         showInputBox:false,
         prefValues:[],
         prefCount:[0],
        prefVal:[]


 };
 this.onload1 = this.onload1.bind(this);
 this.clear = this.clear.bind(this);
 this.change=this.change.bind(this);
 this.handleClick=this.handleClick.bind(this);
 this.toggleFilter=this.toggleFilter.bind(this);
 this.toggleFilter1=this.toggleFilter1.bind(this);
 this.loadDashboard=this.loadDashboard.bind(this);
  this.loadDashboard1=this.loadDashboard1.bind(this);
 this.handleChange=this.handleChange.bind(this);


}


datadownload(val,name){
var that = this;
  axios.get('/datadownload',{
    params: {
      bUnit : this.convertVal(this.state.divVal),
      division :  this.convertVal(this.state.divisionVal),
      region: this.convertVal(this.state.regVal),
      market: this.convertVal(this.state.mrktVal),
      store: this.convertVal(this.state.storenumVal),
      storeV: this.convertVal(this.state.strvolVal),
        job: this.convertVal(this.state.jobVal),
     dept: this.convertVal(this.state.deptVal),
     pft : this.convertVal(this.state.pftVal),
     grade: this.convertVal(this.state.gradeVal),
     timec: this.convertVal(this.state.timecVal),
      timef: this.convertVal(this.state.timefVal),
      timer: this.convertVal(this.state.timerVal),
      jobc: this.convertVal(this.state.jobcVal),
      filVal:val,
      filName :name
    }
  })
  .then(res => {
    const posts = res.data.downData;
    var data = posts;
    if(res.data == "")
           return;
       
       that.JSONToCSVConvertor(data, "Full data", true);
   
  });
}

JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {
	console.log(JSONData);
   
   var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
   
   var CSV = '';    
   
  //  CSV += ReportTitle + '\r\n\n';

   if (ShowLabel) {
       var row = "";
       var keys = Object.keys(arrData[0]);
       for (var index in keys) {
           
           
           row += keys[index] + '\t';
       }

       row = row.slice(0, -1);
       
       CSV += row + '\r\n';
   }
   
   for (var i = 0; i < arrData.length; i++) {
       var row = "";
       
       for (var index in arrData[i]) {
           row += '' + arrData[i][index] + '\t';
       }

       row.slice(0, row.length - 1);
       
       CSV += row + '\r\n';
   }

   if (CSV == '') {        
       alert("Invalid data");
       return;
   }   
   
   var fileName = "";
   fileName += ReportTitle.replace(/ /g,"_");   
   
   var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
   var fname="data"+Math.random()+".xls";
   
  var blobdata = new Blob([CSV],{type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
	var link = document.createElement("a");
	link.setAttribute("href", window.URL.createObjectURL(blobdata));
	link.setAttribute("download", fname);
	document.body.appendChild(link);
	link.click();
   	document.body.removeChild(link);
 
    }
  

isNullOrUndefined(name) {
 if ( name == null || name === '' || name === undefined ) {
	
	return false;
 }else{
 
	 return true;
	 }
 
}

closeTimebox(){

  document.getElementById("TimeFrameMenu").style.display = 'none';
}

closeFilterbox(a){
  
  document.getElementById("FilterMenu").style.display = 'none';
  document.getElementById("filcls").classList.add("clsHeader");
  document.getElementById("filcur").classList.remove("clsHeader");
  // if(a=="alert"){
  //   setTimeout(function(){ 
  //    alert("Please select the filters and click on save");
  //   }, 300);
     
  // }
}

updateCheck(val) {
 
          
    this.setState((oldState) => {
          if(val =="all" && oldState.checkedA == false){ 
             measureVal=measureVal;
           }else if(val =="all" && oldState.checkedA == true){
             measureVal=[];
           }
           if(val ==0 && oldState.checked == false){ 
             measureVal.push("Headcount");
           }else if(val ==0 && oldState.checked == true){
             var a = measureVal.indexOf("Headcount");
             measureVal.splice(a,1);
           }
           if(val ==1 && oldState.checked1 == false){ 
             measureVal.push("Exit");
           }else if(val ==1 && oldState.checked1 == true){
             var a = measureVal.indexOf("Exit");
             measureVal.splice(a,1);
           }
           if(val ==2 && oldState.checked2 == false){ 
             measureVal.push("Turnover");
           }else if(val ==2 && oldState.checked2 == true){
             var a = measureVal.indexOf("Turnover");
             measureVal.splice(a,1);
           }
           if(val ==3 && oldState.checked3 == false){ 
             measureVal.push("Vacancy")
           }else if(val ==3 && oldState.checked3 == true){
             var a = measureVal.indexOf("Vacancy");
             measureVal.splice(a,1);
           }
           if(val ==4 && oldState.checked4 == false){ 
             measureVal.push("Open Req")
           }else if(val ==4 && oldState.checked4 == true){
             var a = measureVal.indexOf("Open Req");
             measureVal.splice(a,1);
           }
           if(val ==5 && oldState.checked5== false){ 
             measureVal.push("4+ Absenteeism")
           }else if(val ==5 && oldState.checked5 == true){
             var a = measureVal.indexOf("4+ Absenteeism");
             measureVal.splice(a,1);
           }
           if(val ==6 && oldState.checked6 == false){ 
             measureVal.push("AB PT Turnover")
           }else if(val ==6 && oldState.checked6 == true){
             var a = measureVal.indexOf("AB PT Turnover");
             measureVal.splice(a,1);
           }
            if(val ==7 && oldState.checked7 == false){ 
             measureVal.push("9+ Absenteeism")
           }else if(val ==7 && oldState.checked7 == true){
             var a = measureVal.indexOf("9+ Absenteeism");
             measureVal.splice(a,1);
           }
       if(val== 0){
          
         return{
            checked: !oldState.checked,
            checkedA :false
            
         };
         
       }
       if(val== 1){
          return {
            checked1: !oldState.checked1,
             checkedA :false
          };
       }
       if(val== 2){
          return {
            checked2: !oldState.checked2,
             checkedA :false
          };
       }
       if(val== 3){
          return {
            checked3: !oldState.checked3,
             checkedA :false
          };
       }
       if(val== 4){
          return {
            checked4: !oldState.checked4,
             checkedA :false
          };
       }
       if(val== 5){
          return {
            checked5: !oldState.checked5,
             checkedA :false
          };
       }
       if(val== 6){
         return {
            checked6: !oldState.checked6,
             checkedA :false
         };
       }
       if(val== 7){
         return {
            checked7: !oldState.checked7,
             checkedA :false
         };
       }
       if(val== "all" && oldState.checkedA==true){
         return {
            checkedA: !oldState.checkedA,
            checked: false,
            checked1: false,
            checked2: false,
            checked3: false,
            checked4: false,
            checked5: false,
            checked6: false,
            checked7: false
         };
       }
       if(val== "all" && oldState.checkedA==false){
         return {
            checkedA: !oldState.checkedA,
            checked: true,
            checked1: true,
            checked2: true,
            checked3: true,
            checked4: true,
            checked5: true,
            checked6: true,
            checked7: true
         };
       }

    

    });
    

  }

  compbg(){

    var id=yearVal[0];

     if((id.toString()).includes("-Q")){
         document.getElementById("ptpbuttonQ").classList.add("bgCol");

    var abc = (this.state.qtr).concat(this.state.qtr1).concat(this.state.qtr2).concat(this.state.qtr3);

      var a = abc.indexOf(yearVal[0]);
      var b = abc.indexOf(yearVal[1]);
       var c=Math.min(a,b);
      var d=Math.max(a,b);
      var interVal = abc.slice(c, d+1);

      for(var i=0;i<interVal.length;i++){
        
        if(i==0 || i==(interVal.length - 1)){
          (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#007dc5")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#007dc5");
        }else{
        // document.getElementById(interVal[i]).classList.add("bgCol");
        (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#5aa7c2")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#5aa7c2");
        }

      }
      document.getElementById("quarterid1").classList.add("quarterclass1");
      document.getElementById("quarterid2").classList.add("quarterclass2");
      document.getElementById("quarterid3").classList.add("quarterclass3");
      var yv_0 = yearVal[0].split("-");
      var yv_1= yearVal[1].split("-");
      if(yv_0[0] != yv_1[0]){

        var min = Math.min(yv_0[0],yv_1[0]);
        var max = Math.max(yv_0[0],yv_1[0]);
        if(min == yv_0[0]){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }else  if(yv_0[0] == yv_1[0]){

        var min = Math.min(yv_0[1].slice(1,3),yv_1[1].slice(1,3));
        var max = Math.max(yv_0[1].slice(1,3),yv_1[1].slice(1,3));
        if(min == yv_0[1].slice(1,3)){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }
  }else if((id.toString()).includes("-")){
     document.getElementById("ptpbuttonP").classList.add("bgCol");

    // var abc = (this.state.p2p1).concat(this.state.p2p2).concat(this.state.p2p3).concat(this.state.p2p4);
    var abc = (this.state.p2p1).concat(this.state.p2p1_1).concat(this.state.p2p1_2).concat(this.state.p2p1_3)
    .concat(this.state.p2p2).concat(this.state.p2p2_1).concat(this.state.p2p2_2).concat(this.state.p2p2_3)
    .concat(this.state.p2p3).concat(this.state.p2p3_1).concat(this.state.p2p3_2).concat(this.state.p2p3_3)
    .concat(this.state.p2p4).concat(this.state.p2p4_1).concat(this.state.p2p4_2).concat(this.state.p2p4_3);

      var a = abc.indexOf(yearVal[0]);
      var b = abc.indexOf(yearVal[1]);
      var c=Math.min(a,b);
      var d=Math.max(a,b);
      var interVal = abc.slice(c, d+1);

      for(var i=0;i<interVal.length;i++){

         if(i==0 || i==(interVal.length - 1)){
          (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#007dc5")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#007dc5");
        }else{
        // document.getElementById(interVal[i]).classList.add("bgCol");
        (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#5aa7c2")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#5aa7c2");
        }

        // document.getElementById(interVal[i]).classList.add("bgCol");

      }
       var yv_0 = yearVal[0].split("-");
      var yv_1= yearVal[1].split("-");
      if(yv_0[0] != yv_1[0]){

        var min = Math.min(yv_0[0],yv_1[0]);
        var max = Math.max(yv_0[0],yv_1[0]);
        if(min == yv_0[0]){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }else  if(yv_0[0] == yv_1[0]){

        var min = Math.min(yv_0[1],yv_1[1]);
        var max = Math.max(yv_0[1],yv_1[1]);
        if(min == yv_0[1]){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }
  }else if(!((id.toString()).includes("-"))){
 document.getElementById("ptpbuttonY").classList.add("bgCol");
    var abc = yeardata;

      var a = abc.indexOf(yearVal[0]);
      var b = abc.indexOf(yearVal[1]);
       var c=Math.min(a,b);
      var d=Math.max(a,b);
      var interVal = abc.slice(c, d+1);

      for(var i=0;i<interVal.length;i++){
         if(i==0 || i==(interVal.length - 1)){
          (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#007dc5")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#007dc5");
        }else{
        // document.getElementById(interVal[i]).classList.add("bgCol");
        (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#5aa7c2")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#5aa7c2");
        }

        // document.getElementById(interVal[i]).classList.add("bgCol");

      }
        var min = Math.min(yearVal[0],yearVal[1]);
        var max = Math.max(yearVal[0],yearVal[1]);
        if(min == yearVal[0]){
          yearVal;
        }else{
          yearVal.reverse();
        }
     
  }
     }

  compFrame(e,values){



 this.setState({comprVal: values });
 count=0;
 yearVal=[];
 this.setState({timeframe:[]});
 var remCls = document.getElementsByClassName("wAuto");
 var remCls_p2p=document.getElementsByClassName("p2pAuto");
 for(var i=0;i<remCls.length;i++){

remCls[i].children[0].classList.remove("bgCol");

 }
 for(var j=0;j<remCls_p2p.length;j++){

remCls_p2p[j].children[0].classList.remove("bgCol");

 }
 if(values == "Year"){
    actualVal=[];
 this.setState({yearDis:false,qtrDis:true,p2pDis:true,timeView:"3",actualVal0:[],actualVal1:[],
showyr : true, showqtr :false, showprd :false});
 document.getElementById("ptpbuttonY").classList.add("bgCol");
 document.getElementById("ptpbuttonQ").classList.remove("bgCol");
 document.getElementById("ptpbuttonP").classList.remove("bgCol");
  document.getElementById("quarterid1").classList.remove("quarterclass1");
  document.getElementById("quarterid2").classList.remove("quarterclass2");
  document.getElementById("quarterid3").classList.remove("quarterclass3");
 initYear=[];
 startDate="";
endDate="";
 }
  if(values == "Quarter"){
     actualVal=[];
 this.setState({yearDis:true,qtrDis:false,p2pDis:true,timeView:"2",actualVal0:[],actualVal1:[],
showyr : true, showqtr :true, showprd :false}, function () {
  document.getElementById("quarterid1").classList.add("quarterclass1");
  document.getElementById("quarterid2").classList.add("quarterclass2");
  document.getElementById("quarterid3").classList.add("quarterclass3");
  });
 // 
  document.getElementById("ptpbuttonY").classList.remove("bgCol");
 document.getElementById("ptpbuttonQ").classList.add("bgCol");
 document.getElementById("ptpbuttonP").classList.remove("bgCol");
  initYear=[];
   startDate="";
endDate="";
 }
  if(values == "Period"){
     actualVal=[];
 this.setState({yearDis:true,qtrDis:true,p2pDis:false,timeView:"1",actualVal0:[],actualVal1:[],
showyr : true, showqtr :true, showprd :true});
  document.getElementById("ptpbuttonY").classList.remove("bgCol");
 document.getElementById("ptpbuttonQ").classList.remove("bgCol");
 document.getElementById("ptpbuttonP").classList.add("bgCol");
  document.getElementById("quarterid1").classList.remove("quarterclass1");
  document.getElementById("quarterid2").classList.remove("quarterclass2");
  document.getElementById("quarterid3").classList.remove("quarterclass3");
  initYear=[];
   startDate="";
endDate="";
 }
  if(values == "clear"){
     actualVal=[];
 document.getElementById("ptpbuttonY").classList.remove("bgCol");
 document.getElementById("ptpbuttonQ").classList.remove("bgCol");
 document.getElementById("ptpbuttonP").classList.remove("bgCol");
 this.setState({comprVal: "" });
 this.setState({yearDis:true,qtrDis:true,p2pDis:true,timeView:"",actualVal0:[],actualVal1:[],
showyr : false, showqtr :false, showprd :false});
  initYear=[];
   startDate="";
endDate="";
 return;
 }
   if(values == "default"){
  if(document.getElementById("ptpbuttonY") != null && document.getElementById("ptpbuttonQ")!=null &&document.getElementById("ptpbuttonP") !=null){
 document.getElementById("ptpbuttonY").classList.add("bgCol");
 document.getElementById("ptpbuttonQ").classList.remove("bgCol");
 document.getElementById("ptpbuttonP").classList.remove("bgCol");
 }
 this.setState({comprVal: "Year", showyr : true, showqtr :false, showprd :false});
 this.setState({yearDis:false,qtrDis:true,p2pDis:true,timeView:"",actualVal0:[],actualVal1:[]});
 var yrData =yeardata;
 var indexYrData = yrData.indexOf("");
if(indexYrData > -1){
  yrData.splice(indexYrData,1);
}
 var maxvalue = Math.max.apply(null, yeardata);
 var minvalue = Math.min.apply(null, yeardata);
 yearVal.push(minvalue);
 yearVal.push(maxvalue);
 this.getActualDate(yearVal);
 this.setState({timeframe:yearVal});
 var abc = yeardata;
var a = abc.indexOf(yearVal[0]);
var b = abc.indexOf(yearVal[1]);
var interVal = abc.slice(a, b+1);
 if( document.getElementById(yearVal[0]) !=null){
document.getElementById(yearVal[0]).parentNode.children[0].firstChild.children[0].children[0].style.backgroundColor="#007dc5";
document.getElementById(yearVal[1]).parentNode.children[0].firstChild.children[0].children[0].style.backgroundColor="#007dc5";
 }
interVal.shift();
interVal.pop();
for(var i=0;i<interVal.length;i++){
  if( document.getElementById(interVal[i]) !=null){
  document.getElementById(interVal[i]).parentNode.children[0].firstChild.children[0].children[0].style.backgroundColor="#5aa7c2";
}

}
 }

}

year(val,id){
  id=(id.name) ? id.name :id;
  count=count+1;
  if(count==1){
  yearVal.push(id);
 this.getActualDate(yearVal);
   val.currentTarget.parentNode.children[0].firstChild.children[1].children[0].style.backgroundColor="#007dc5";
  }
  if(count==2){
  yearVal.push(id);
   val.currentTarget.parentNode.children[0].firstChild.children[1].children[0].style.backgroundColor="#007dc5";
  if((id.toString()).includes("-Q")){

    var abc = (this.state.qtr).concat(this.state.qtr1).concat(this.state.qtr2).concat(this.state.qtr3);

      var a = abc.indexOf(yearVal[0]);
      var b = abc.indexOf(yearVal[1]);
       var c=Math.min(a,b);
      var d=Math.max(a,b);
      var interVal = abc.slice(c, d+1);
      interVal.shift();
      interVal.pop();

      for(var i=0;i<interVal.length;i++){

        (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#5aa7c2")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#5aa7c2");

        //    (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        // (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.color="#0065b8")
        //  :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.color="#0065b8")#EDF7FF;#299fc7;

      }
      var yv_0 = yearVal[0].split("-");
      var yv_1= yearVal[1].split("-");
      if(yv_0[0] != yv_1[0]){

        var min = Math.min(yv_0[0],yv_1[0]);
        var max = Math.max(yv_0[0],yv_1[0]);
        if(min == yv_0[0]){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }else  if(yv_0[0] == yv_1[0]){

        var min = Math.min(yv_0[1].slice(1,3),yv_1[1].slice(1,3));
        var max = Math.max(yv_0[1].slice(1,3),yv_1[1].slice(1,3));
        if(min == yv_0[1].slice(1,3)){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }
  }else if((id.toString()).includes("-")){

    var abc = (this.state.p2p1).concat(this.state.p2p1_1).concat(this.state.p2p1_2).concat(this.state.p2p1_3)
    .concat(this.state.p2p2).concat(this.state.p2p2_1).concat(this.state.p2p2_2).concat(this.state.p2p2_3)
    .concat(this.state.p2p3).concat(this.state.p2p3_1).concat(this.state.p2p3_2).concat(this.state.p2p3_3)
    .concat(this.state.p2p4).concat(this.state.p2p4_1).concat(this.state.p2p4_2).concat(this.state.p2p4_3);
      
      var a = abc.indexOf(yearVal[0]);
      var b = abc.indexOf(yearVal[1]);
      var c=Math.min(a,b);
      var d=Math.max(a,b);
      var interVal = abc.slice(c, d+1);
      interVal.shift();
      interVal.pop();
      for(var i=0;i<interVal.length;i++){

         (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#5aa7c2")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#5aa7c2");

      }
       var yv_0 = yearVal[0].split("-");
      var yv_1= yearVal[1].split("-");
      if(yv_0[0] != yv_1[0]){

        var min = Math.min(yv_0[0],yv_1[0]);
        var max = Math.max(yv_0[0],yv_1[0]);
        if(min == yv_0[0]){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }else  if(yv_0[0] == yv_1[0]){

        var min = Math.min(yv_0[1],yv_1[1]);
        var max = Math.max(yv_0[1],yv_1[1]);
        if(min == yv_0[1]){
          yearVal;
        }else{
          yearVal.reverse();
        }

      }
  }else if(!((id.toString()).includes("-"))){

    var abc = yeardata;

      var a = abc.indexOf(yearVal[0]);
      var b = abc.indexOf(yearVal[1]);
      
      var c=Math.min(a,b);
      var d=Math.max(a,b);
      var interVal = abc.slice(c, d+1);
      
      interVal.shift();
      interVal.pop();
      for(var i=0;i<interVal.length;i++){

         (document.getElementById(interVal[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(interVal[i]).firstChild.children[1].children[0].style.backgroundColor="#5aa7c2")
         :  (document.getElementById(interVal[i]).firstChild.children[0].children[0].style.backgroundColor="#5aa7c2");

      }
        var min = Math.min(yearVal[0],yearVal[1]);
        var max = Math.max(yearVal[0],yearVal[1]);
        if(min == yearVal[0]){
          yearVal;
        }else{
          yearVal.reverse();
        }
     
  }
  this.getActualDate(yearVal);
  }
   if(count>2){

 if(yearVal.indexOf(id) != -1){
  val.currentTarget.parentNode.children[0].firstChild.children[1].children[0].style.backgroundColor="transparent";
 var index = yearVal.indexOf(id);
 yearVal.splice(index,1);
  if((id.toString()).includes("-Q")){
    var abc = (this.state.qtr).concat(this.state.qtr1).concat(this.state.qtr2).concat(this.state.qtr3);
      for(var i=0;i<abc.length;i++){
        if(abc[i] != yearVal[0]){
         (document.getElementById(abc[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(abc[i]).firstChild.children[1].children[0].style.backgroundColor="transparent")
         :  (document.getElementById(abc[i]).firstChild.children[0].children[0].style.backgroundColor="transparent");
        }
      }
      
     
  }else if(!((id.toString()).includes("-"))){

    var abc = yeardata;
     var yrData =abc;
      var indexYrData = yrData.indexOf("");
      if(indexYrData > -1){
        abc.splice(indexYrData,1);
      }
      for(var i=0;i<abc.length;i++){
        if(abc[i] != yearVal[0]){
          (document.getElementById(abc[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(abc[i]).firstChild.children[1].children[0].style.backgroundColor="transparent")
         :  (document.getElementById(abc[i]).firstChild.children[0].children[0].style.backgroundColor="transparent");
        }
      }
  }else if((id.toString()).includes("-")){

     var abc = (this.state.p2p1).concat(this.state.p2p1_1).concat(this.state.p2p1_2).concat(this.state.p2p1_3)
    .concat(this.state.p2p2).concat(this.state.p2p2_1).concat(this.state.p2p2_2).concat(this.state.p2p2_3)
    .concat(this.state.p2p3).concat(this.state.p2p3_1).concat(this.state.p2p3_2).concat(this.state.p2p3_3)
    .concat(this.state.p2p4).concat(this.state.p2p4_1).concat(this.state.p2p4_2).concat(this.state.p2p4_3);
     for(var i=0;i<abc.length;i++){
        if(abc[i] != yearVal[0]){
          (document.getElementById(abc[i]).firstChild.children[1] != undefined) ?
        (document.getElementById(abc[i]).firstChild.children[1].children[0].style.backgroundColor="transparent")
         :  (document.getElementById(abc[i]).firstChild.children[0].children[0].style.backgroundColor="transparent");
        }
      }
  }
  
   count=1;
   this.getActualDate(yearVal);
 }
    
  }
  prevValue=(id.name) ? id.name : id;
  this.setState({timeframe:yearVal});
  
}


convertVal(val){
 var abc=[];
for(var i=0;i<val.length;i++){

 abc.push(val[i].value);
}
return abc;
}
conv(val){
var abc=[];
for(var j=0;j<val.length;j++){
abc.push({value:val[j]});

}
return abc;
}

loadFilters(){
  var that = this;
   axios.get('/getSegmentData')
 .then(res => {
  const posts = res.data;
  console.log(res);
  that.setState({div:res.data.bUnit,division:res.data.division,reg:res.data.region,mrkt:res.data.market,
    storenum:res.data.store,strvol:res.data.storevol});
  });
  axios.get('/getDeptData')
 .then(res => {
  const posts = res.data;
  console.log(res);
  that.setState({dept:res.data.dept});
  });
  axios.get('/getPeopleData')
 .then(res => {
  const posts = res.data;
  console.log(res);
  that.setState({job:res.data.job,grade:res.data.grade,timec:res.data.timec,timef:res.data.timec,timer:res.data.timec,jobc:res.data.jobc});

  });
  axios.get('/getPftMeasure')
 .then(res => {
  const posts = res.data;
  console.log(res);
  that.setState({pft:res.data.pft});
  measureVal = res.data.measure;
  });
}
loadFilters2(e,a){


  var that = this;
  var bUnit=[];
  var division=[];
  var region =[];
  var market =[];
  var store =[];
  var storeV=[];
  var x;
   x=a;
   if(a=="div"){
    bUnit = e;
	 division=this.state.divisionVal;
	region=this.state.regVal;
	market=this.state.mrktVal;
	store=this.state.storenumVal;
	storeV=this.state.strvolVal;
    a="BUSINESS_UNIT";
  }else if(a=="division"){
    division=e;
	bUnit=this.state.divVal;
	region=this.state.regVal;
	market=this.state.mrktVal;
	store=this.state.storenumVal;
	storeV=this.state.strvolVal;
    a="Division";
  }else if(a=="reg"){
    region=e;
	bUnit=this.state.divVal;
	 division=this.state.divisionVal;
	market=this.state.mrktVal;
	store=this.state.storenumVal;
	storeV=this.state.strvolVal;
    a="REGION_NAME";
  }else if(a=="mrkt"){
    market=e;
		bUnit=this.state.divVal;
	 division=this.state.divisionVal;
	region=this.state.regVal;
	store=this.state.storenumVal;
	storeV=this.state.strvolVal;
    a="MARKET_AREA_NAME";
  }else if(a=="storenum"){
    store=e;
		bUnit=this.state.divVal;
	 division=this.state.divisionVal;
	region=this.state.regVal;
	market=this.state.mrktVal;
	storeV=this.state.strvolVal;
    a="STORE_NBR";
  }else if(a=="strvol"){
    storeV=e;
		bUnit=this.state.divVal;
	 division=this.state.divisionVal;
	region=this.state.regVal;
	market=this.state.mrktVal;
	store=this.state.storenumVal;
    a="Store_Volume";
  }
  
  if(a=="dept" && e.length >0){
  this.toggleFilter(a);
  }else if(a=="dept" && e.length ==0){
  this.toggleFilter1(a);
  } 

   if(a=="org" && e.length >0){
  this.toggleFilter(a);
  }else if(a=="org" && e.length ==0){
  this.toggleFilter1(a);
  } 
  if(e.length > 0){
 this.toggleFilter(a);
  axios.get('/changeVal',{
    params: {
      bUnit : this.convertVal(bUnit),
      division :  this.convertVal(division),
      region: this.convertVal(region),
      market: this.convertVal(market),
      store: this.convertVal(store),
      storeV: this.convertVal(storeV),
      filter :a
    }
  })
  .then(res => {
    const posts = res.data;
    console.log(res);
    if(a=="REGION_NAME"){
      that.setState({div:res.data.bUnit,division:res.data.division,mrkt:res.data.market,
        storenum:res.data.store,strvol:res.data.storeV});
    }else if(a=="BUSINESS_UNIT"){
      that.setState({division:res.data.division,reg:res.data.region,mrkt:res.data.market,
        storenum:res.data.store,strvol:res.data.storeV});
    }else if(a=="Division"){
      that.setState({div:res.data.bUnit,reg:res.data.region,mrkt:res.data.market,
        storenum:res.data.store,strvol:res.data.storeV});
    }else if(a=="MARKET_AREA_NAME"){
      that.setState({div:res.data.bUnit,division:res.data.division,reg:res.data.region,
        storenum:res.data.store,strvol:res.data.storeV});
    }else if(a=="Store_Volume"){
      that.setState({div:res.data.bUnit,division:res.data.division,reg:res.data.region,mrkt:res.data.market, storenum:res.data.store});
    }else if(a=="STORE_NBR"){
      that.setState({div:res.data.bUnit,division:res.data.division,reg:res.data.region,mrkt:res.data.market,strvol:res.data.storeV});
    }
  });
}else{
 this.clear(x);
 this.toggleFilter1(a);
}
}

loadPeople2(e,a){


  var that = this;
  var jobc=[];
  var job=[];
 var x;
 x=a;
  if(a=="job"){
    job=e;
    a="Job_Family";
  }else if(a=="jobc"){
    jobc=e;
    a="JOB_CODE";
  }
   if((a=="timec" || a=="timer" || a=="timef" || a=="grade") && (e.length>0)){
  this.toggleFilter(a);
  }else{
  this.toggleFilter1(a);
  } 
  // if(a=="grade"){
  //   a=jobc;
  // }
  if(e.length > 0){
  this.toggleFilter(a);
  axios.get('/changeJobVal',{
    params: {
      jobc : this.convertVal(jobc),
      job : this.convertVal(job),
      filter :a
    }
  })
  .then(res => {
    const posts = res.data;
    console.log(res);
    if(a=="JOB_CODE"){
      that.setState({job:res.data.job});
    }else if(a=="Job_Family"){
      that.setState({jobc:res.data.jobc});
    }
  });
}else{
 this.clear(x);
 this.toggleFilter1(a);
}
}

clearFilters(e,a){


  var that = this;
  var bUnit=[];
  var division=[];
  var region =[];
  var market =[];
  var store =[];
  if(a=="div" || a=="BUSINESS_UNIT"){
    a="BUSINESS_UNIT";
  }else if(a=="division" || a=="Division"){
    a="Division";
  }else if(a=="reg" || a=="REGION_NAME"){
    a="REGION_NAME";
  }else if(a=="mrkt" || a=="MARKET_AREA_NAME"){
    a="MARKET_AREA_NAME";
  }else if(a=="storenum" || a=="STORE_NBR"){
    a="STORE_NBR";
  }else if(a=="strvol" || a=="Store_Volume"){
    a="Store_Volume";
  }
  axios.get('/clearVal',{
    params: {
      bUnit : that.convertVal(that.state.divVal),
      division : that.convertVal(that.state.divisionVal),
      region:that.convertVal(that.state.regVal),
      market:that.convertVal(that.state.mrktVal),
      store:that.convertVal(that.state.storenumVal),
      storeV:that.convertVal(that.state.strvolVal),
      filter :a
    }
  })
  .then(res => {
    const posts = res.data;
    console.log(res);

     var filtersSet=[];
     var filtersReload=[];
     if(that.state.divVal != undefined && that.state.divVal !="" && that.state.divVal!=[]){

        filtersSet.push("divVal");
    }else{

       filtersReload.push("divVal");

    }

     if(that.state.divisionVal != undefined && that.state.divisionVal !="" && that.state.divisionVal!=[]){

        filtersSet.push("divisionVal");
    }else {

       filtersReload.push("divisionVal");
       filtersReload.push("regVal");
       filtersReload.push("mrktVal");
       filtersReload.push("storenumVal");
       filtersReload.push("strvolVal");

    }


      if(that.state.regVal != undefined && that.state.regVal !="" && that.state.regVal!=[]){

        filtersSet.push("regVal");
    }else {

       filtersReload.push("regVal");
       filtersReload.push("mrktVal");
       filtersReload.push("storenumVal");
       filtersReload.push("strvolVal");

    }

 if(that.state.mrktVal != undefined && that.state.mrktVal !="" && that.state.mrktVal!=[]){

        filtersSet.push("mrktVal");
    }else {

       filtersReload.push("mrktVal");
       filtersReload.push("storenumVal");
       filtersReload.push("strvolVal");

    }

    if(that.state.storenumVal != undefined && that.state.storenumVal !="" && that.state.storenumVal!=[]){

        filtersSet.push("storenumVal");
    }else {

       filtersReload.push("storenumVal");
       filtersReload.push("strvolVal");

    }

    if(that.state.strvolVal != undefined && that.state.strvolVal !="" && that.state.strvolVal!=[]){

        filtersSet.push("strvolVal");
    }else {

       filtersReload.push("strvolVal");

    }

     for(var i=0; i<filtersSet.length; i++){

    if(filtersSet[i] == "divVal"){

        that.setState({div:that.convertVal(that.state.divVal)});

    }
    if(filtersSet[i] == "divisionVal"){

        that.setState({division:that.convertVal(that.state.divisionVal)});

    }
    if(filtersSet[i] == "regVal"){

        that.setState({reg:that.convertVal(that.state.regVal)});

    }
    if(filtersSet[i] == "mrktVal"){

        that.setState({mrkt:that.convertVal(that.state.mrktVal)});

    }
    if(filtersSet[i] == "storenumVal"){

        that.setState({storenum:that.convertVal(that.state.storenumVal)});

    }
    if(filtersSet[i] == "strvolVal"){

        that.setState({strvol:that.convertVal(that.state.strvolVal)});

    }

    }

    for(var i=0; i<filtersReload.length; i++){

    if(filtersReload[i] == "divVal"){

        that.setState({div:res.data.bUnit});

    }
    if(filtersReload[i] == "divisionVal"){

        that.setState({division:res.data.division});

    }
    if(filtersReload[i] == "regVal"){

        that.setState({reg:res.data.region});

    }
    if(filtersReload[i] == "mrktVal"){

        that.setState({mrkt:res.data.market});

    }
    if(filtersReload[i] == "storenumVal"){

        that.setState({storenum:res.data.store});

    }
    if(filtersReload[i] == "strvolVal"){

        that.setState({strvol:res.data.storeV});

    }

    }

  });
}

clearJobFilters(e,a){


  var that = this;
  var jobc=[];
  var job=[];
  var b="";
  if(a=="grade"){
    b=a;
  }
 if(a=="jobc" || a=="JOB_CODE"){
    a="JOB_CODE";
  }else if(a=="job" || a=="Job_Family" || a=="grade"){
    a="Job_Family";
  }
  axios.get('/clearJobVal',{
    params: {
      jobc : that.convertVal(that.state.jobcVal),
      job : that.convertVal(that.state.jobVal),
      filter :a
    }
  })
  .then(res => {
    const posts = res.data;
    console.log(res);
    if(a=="Job_Family"){
      that.setState({jobc:res.data.jobc,job:res.data.job});
    }else if(a=="JOB_CODE"){
      if(that.state.jobVal == ""){
       that.setState({jobc:res.data.jobc,job:res.data.job});
      }else{
        that.setState({jobc:res.data.jobc,job:that.state.jobVal});
      }
    }
     if(b=="grade"){
      that.setState({grade:res.data.grade});
    }
  });
  
}

getHoverDate(comp,val){

var that =this;
var abc=[];
abc.push(val);
// if(this.state.comprVal !=undefined && this.state.timeframe !=undefined){
 axios.get('/getDate',{
    params: {
      compPrd : comp,
      timeframe : abc
     
    }
  })
  .then(res => {

    var abc=res.data;
    if(res.data.d1){

      // actualVal.push(res.data.d1);
       this.setState({hoverDt:res.data.d1});
      // return res.data.d1;
    }
      
  });
// }

}

getActualDate(val){

var that =this;
if(this.state.comprVal !=undefined && this.state.timeframe !=undefined){
 axios.get('/getDate',{
    params: {
      compPrd : this.state.comprVal,
      timeframe : val
     
    }
  })
  .then(res => {

    var abc=res.data;
    if(res.data.startDate){
      actualVal=[];
     startDate= res.data.startDate; 
     endDate = res.data.endDate ;
     actualVal.push(startDate);
     actualVal.push(endDate);
     this.setState({actualVal0:actualVal[0],actualVal1:actualVal[1]});
    }if(res.data.d1){

      actualVal.push(res.data.d1);
       this.setState({actualVal0:actualVal[0]});
    }
      
  });
}

}

loadDashboard(){

var that =this;
if(this.state.comprVal !=undefined && this.state.timeframe !=undefined ){
 axios.get('/getDate',{
    params: {
      compPrd : this.state.comprVal,
      timeframe : this.state.timeframe
     
    }
  })
  .then(res => {

    var abc=res.data;
     startDate= res.data.startDate; 
     endDate = res.data.endDate ;
      that.props.onData1Changed({divVal:that.state.divVal,divisionVal:that.state.divisionVal,regVal:that.state.regVal,
  mrktVal:that.state.mrktVal,storenumVal:that.state.storenumVal,strvolVal:that.state.strvolVal,deptVal:that.state.deptVal,
  timecVal:that.state.timecVal,timefVal:that.state.timefVal,timerVal:that.state.timerVal,jobVal:that.state.jobVal,
  gradeVal:that.state.gradeVal,compVal:that.state.compVal,pftVal:that.state.pftVal,loadVal:"yes",timeView:that.state.timeView,
startDate:startDate,endDate:endDate,measureVal:measureVal,jobcVal:this.state.jobcVal});
  });
}else{

  this.props.onData1Changed({divVal:this.state.divVal,divisionVal:this.state.divisionVal,regVal:this.state.regVal,
  mrktVal:this.state.mrktVal,storenumVal:this.state.storenumVal,strvolVal:this.state.strvolVal,deptVal:this.state.deptVal,
  timecVal:this.state.timecVal,timefVal:this.state.timefVal,timerVal:this.state.timerVal,jobVal:this.state.jobVal,
  gradeVal:this.state.gradeVal,compVal:this.state.compVal,pftVal:this.state.pftVal,loadVal:"yes",measureVal:measureVal,timeView:this.state.timeView,
startDate:startDate,endDate:endDate,jobcVal:this.state.jobcVal});
}
}

loadDashboardPref(e){
e.stopPropagation();
if(document.getElementsByClassName("prefButton1").length !=0){
  document.getElementsByClassName("prefButton1")[0].classList.remove("prefButton1");
}
if(e.target.className.includes("fa-check-circle")){
  e.target.parentElement.classList.add("prefButton1");
}

this.popFilter(e);
var that =this;
if(this.state.comprVal !=undefined && this.state.timeframe !=undefined ){
 axios.get('/getDate',{
    params: {
      compPrd : this.state.comprVal,
      timeframe : this.state.timeframe
     
    }
  })
  .then(res => {

    var abc=res.data;
     startDate= res.data.startDate; 
     endDate = res.data.endDate ;
      that.props.onData1Changed({divVal:that.state.divVal,divisionVal:that.state.divisionVal,regVal:that.state.regVal,
  mrktVal:that.state.mrktVal,storenumVal:that.state.storenumVal,strvolVal:that.state.strvolVal,deptVal:that.state.deptVal,
  timecVal:that.state.timecVal,timefVal:that.state.timefVal,timerVal:that.state.timerVal,jobVal:that.state.jobVal,
  gradeVal:that.state.gradeVal,compVal:that.state.compVal,pftVal:that.state.pftVal,loadVal:"yes",timeView:that.state.timeView,
startDate:startDate,endDate:endDate,measureVal:measureVal,jobcVal:this.state.jobcVal});
  });
}else{

  this.props.onData1Changed({divVal:this.state.divVal,divisionVal:this.state.divisionVal,regVal:this.state.regVal,
  mrktVal:this.state.mrktVal,storenumVal:this.state.storenumVal,strvolVal:this.state.strvolVal,deptVal:this.state.deptVal,
  timecVal:this.state.timecVal,timefVal:this.state.timefVal,timerVal:this.state.timerVal,jobVal:this.state.jobVal,
  gradeVal:this.state.gradeVal,compVal:this.state.compVal,pftVal:this.state.pftVal,loadVal:"yes",measureVal:measureVal,timeView:this.state.timeView,
startDate:startDate,endDate:endDate,jobcVal:this.state.jobcVal});
}
}

loadDashboard1(){
 this.props.onData1Changed({divVal:"",divisionVal:"",regVal:"",
  mrktVal:"",storenumVal:"",strvolVal:"",deptVal:"",
  timecVal:"",timefVal:"",timerVal:"",jobVal:"",
  gradeVal:"",compVal:"",pftVal:"",loadVal:"yes",measureVal:"",jobcVal:""});
}




handleClick(e,a) {
  if(e=="seg"){
   this.setState({
     ifClickedOpt1 : !this.state.ifClickedOpt1,
     ifClickedOpt2:false
   });
 }else if(e=="ppl"){
  this.setState({
   ifClickedOpt2 : !this.state.ifClickedOpt2,
   ifClickedOpt1 : false
 });
}else if(e=="time"){
  this.setState({
   ifClickedOpt3 : !this.state.ifClickedOpt3,
    displayopt:!this.state.displayopt
 });
 return;
}else if(e=="comp"){
  this.setState({
   ifClickedOpt : this.state.ifClickedOpt
  

 });
 return;
}
a.preventDefault();
if(a.target.parentElement.localName=="p"){
 a.target.parentElement.offsetParent.classList.toggle('open');
 if((a.target.parentNode.parentNode.nextSibling) && (a.target.parentNode.parentNode.nextSibling.classList.contains("open"))) {
  a.target.parentNode.parentNode.nextSibling.classList.toggle('open');
}else  if((a.target.parentNode.parentNode.previousSibling) && (a.target.parentNode.parentNode.previousSibling.classList.contains("open"))) {
 a.target.parentNode.parentNode.previousSibling.classList.toggle('open');
}

}else{
 a.target.parentElement.classList.toggle('open');
 if((a.target.parentNode.nextSibling) && (a.target.parentNode.nextSibling.classList.contains("open"))) {
  a.target.parentNode.nextSibling.classList.toggle('open');
}else  if((a.target.parentNode.previousSibling) && (a.target.parentNode.previousSibling.classList.contains("open"))) {
 a.target.parentNode.previousSibling.classList.toggle('open');
}



}
that = this.props;

}

onload1(a){
  if(a.comprEn==false){
  count=2;
  
  }
  if(a.showCmp==true){

  

  }
  

  this.setState({comprEn:a.comprEn,isHome : a.isHome,measure : a.measure}, function () {

    // var segMenu = document.getElementById("SegmentMenu");
    // var pplMenu =document.getElementById("PeopleMenu");
    if(a.measure ==true){
     this.hidemenu("exeCollapse");
    }

    if(a.measure ==false){
      this.setState({isCollapse:false,measure:false});
    }
     var ele = document.getElementById("timed");
     
   

        if( a.showCmp==true ){
        setTimeout(function(){ 
           if(countEle==0){
            ele = document.getElementById("timed");
            ele.style.backgroundColor="#007dc5";
            countEle++;
              
         
        }
        }, 600);
      
        setTimeout(function(){ 
        if(countEle==1){
        
           
            ele.style.backgroundColor="#76b9e6";
           countEle++;
             
        } }, 1000);

        setTimeout(function(){ 
        if(countEle==2){
        
           
            ele.style.backgroundColor="#007dc5";
           countEle++;
             
        } }, 1500);

        setTimeout(function(){ 
        if(countEle==3){
        
           
            ele.style.backgroundColor="#76b9e6";
           countEle++;
             
        } }, 2000);

         setTimeout(function(){ 
        if(countEle==4){
        
           
          ele.style.backgroundColor="#007dc5";
           countEle++;
             
        } }, 2500);

        setTimeout(function(){ 
        if(countEle==5){
        
           
          ele.style.backgroundColor="#76b9e6";
           countEle++;
             
        } }, 3000);

         setTimeout(function(){ 
        if(countEle==6){
        
           
          ele.style.backgroundColor="#007dc5";
           countEle++;
             
        } }, 3500);

         setTimeout(function(){ 
        if(countEle==7){
        
           
          ele.style.backgroundColor="#76b9e6";
           countEle++;
             
        } }, 4000);

         setTimeout(function(){ 
        if(countEle==8){
        
           
          ele.style.backgroundColor="#007dc5";
           countEle++;
             
        } }, 4500);

         setTimeout(function(){ 
        if(countEle==9){
        
           
          ele.style.backgroundColor="#76b9e6";
           countEle++;
             
        } }, 5000);
        
          setTimeout(function(){ 
        if(countEle==10){
        
           
          ele.style.backgroundColor="#007dc5";
          countEle=0;
             
        } }, 5500);
      } 

  });
  that = this.props;
}


   toggleFilter(a){


      if(a=="BUSINESS_UNIT"){
        this.setState({showDivbox :true,filterVisible:true,filterVisible1:true})
      } else if(a=="Division"){
		this.setState({showDivisionbox:true,filterVisible:true,filterVisible2:true})
	  }else if(a=="REGION_NAME"){
		this.setState({showRegbox:true,filterVisible:true,filterVisible3:true})
	  }else if(a=="MARKET_AREA_NAME"){
		this.setState({showMarktbox:true,filterVisible:true,filterVisible4:true})
	  }else if(a=="STORE_NBR"){
		this.setState({showStorebox:true,filterVisible:true,filterVisible5:true})
	  }else if(a=="dept"){
		this.setState({showDeptbox:true,filterVisible:true,filterVisible6:true})
	  }else if(a=="grade"){
		this.setState({showGradebox:true,filterVisible:true,filterVisible7:true})
	  }else if(a=="Job_Family"){
		this.setState({showJobbox:true,filterVisible:true,filterVisible8:true})
	  }else if(a=="JOB_CODE"){
		this.setState({showJobbox:true,filterVisible:true,filterVisible23:true})
	  }else if(a=="timec"){
		this.setState({showTimecbox:true,filterVisible:true,filterVisible9:true})
	  }else if(a=="timef"){
		this.setState({showTimefbox:true,filterVisible:true,filterVisible10:true})
	  }else if(a=="timer"){
		this.setState({showTimerbox:true,filterVisible:true,filterVisible11:true})
	  }else if(a=="Store_Volume"){
    this.setState({filterVisible:true,filterVisible20:true})
    }else if(a=="org"){
    this.setState({filterVisible:true,filterVisible21:true})
    }
	 
	 

  }

  
   toggleFilter1(a){


      if(a=="BUSINESS_UNIT"){
        this.setState({showDivbox :true,filterVisible:true,filterVisible1:false})
      } else if(a=="Division"){
		this.setState({showDivisionbox:true,filterVisible:true,filterVisible2:false})
	  }else if(a=="REGION_NAME"){
		this.setState({showRegbox:true,filterVisible:true,filterVisible3:false})
	  }else if(a=="MARKET_AREA_NAME"){
		this.setState({showMarktbox:true,filterVisible:true,filterVisible4:false})
	  }else if(a=="STORE_NBR"){
		this.setState({showStorebox:true,filterVisible:true,filterVisible5:false})
	  }else if(a=="dept"){
		this.setState({showDeptbox:true,filterVisible:true,filterVisible6:false})
	  }else if(a=="grade"){
		this.setState({showGradebox:true,filterVisible:true,filterVisible7:false})
	  }else if(a=="Job_Family"){
		this.setState({showJobbox:true,filterVisible:true,filterVisible8:false})
	  }else if(a=="JOB_CODE"){
		this.setState({showJobbox:true,filterVisible:true,filterVisible23:false})
	  }else if(a=="timec"){
		this.setState({showTimecbox:true,filterVisible:true,filterVisible9:false})
	  }else if(a=="timef"){
		this.setState({showTimefbox:true,filterVisible:true,filterVisible10:false})
	  }else if(a=="timer"){
		this.setState({showTimerbox:true,filterVisible:true,filterVisible11:false})
	  }else if(a=="Store_Volume"){
    this.setState({filterVisible:true,filterVisible20:false})
    }else if(a=="org"){
    this.setState({filterVisible:true,filterVisible21:false})
    }
  if(this.state.divVal=="" && this.state.divisionVal=="" && this.state.regVal==""&& this.state.mrktVal==""&& this.state.gradeVal==""&& this.state.jobVal==""&&
  this.state.timecVal==""&&this.state.timerVal==""&&this.state.timefVal==""&&this.state.storenumVal==""&&this.state.deptVal==""&&
  this.state.strvolVal==""&&this.state.orgVal==""&&this.state.jobcVal==""){
  this.setState({filterVisible:false})
  }
  }
  
  clear(val){

    if(val=="div"){
      this.setState({divVal: [],divisionVal:[],regVal:[],mrktVal:[],strvolVal:[],storenumVal:[],deptVal:[],filterVisible1:false,filterVisible2:false,filterVisible3:false,filterVisible4:false,
    filterVisible5:false,filterVisible20:false,filterVisible6:false});
      this.clearFilters([],val);
    }else if(val=="division"){
      this.setState({divisionVal:[],regVal:[],mrktVal:[],strvolVal:[],storenumVal:[],deptVal:[],filterVisible2:false,filterVisible3:false,filterVisible4:false,
    filterVisible5:false,filterVisible20:false,filterVisible6:false});
      this.clearFilters([],val);
    }else if(val=="reg"){
      this.setState({regVal:[],mrktVal:[],strvolVal:[],storenumVal:[],deptVal:[],filterVisible3:false,filterVisible4:false,
    filterVisible5:false,filterVisible20:false,filterVisible6:false});
      this.clearFilters([],val);
    }else if(val=="mrkt"){
      this.setState({mrktVal:[],strvolVal:[],storenumVal:[],storenumVal:[],deptVal:[],filterVisible4:false,filterVisible5:false,filterVisible20:false,filterVisible6:false});
      this.clearFilters([],val);
    }else if(val=="strvol"){
       this.setState({strvolVal:[],storenumVal:[],deptVal:[],filterVisible20:false,filterVisible5:false,filterVisible6:false});
      this.clearFilters([],val);
    }else if(val=="storenum"){
      this.setState({storenumVal:[],deptVal:[],filterVisible5:false,filterVisible6:false});
      this.clearFilters([],val);
    }else if(val=="dept"){
      this.setState({deptVal:[],filterVisible6:false});
    }else if(val=="grade"){
      this.setState({gradeVal:[],jobVal:[],jobcVal:[],timecVal:[],timefVal:[],timerVal:[],filterVisible7:false,filterVisible8:false,filterVisible9:false,filterVisible10:false,
    filterVisible11:false,filterVisible22:false,filterVisible23:false});
    this.clearJobFilters([],val);
    }else if(val=="job"){
      this.setState({jobVal:[],jobcVal:[],timecVal:[],timefVal:[],timerVal:[],filterVisible8:false,filterVisible9:false,filterVisible10:false,
    filterVisible11:false,filterVisible22:false,filterVisible23:false});
      this.clearJobFilters([],val);
    }else if(val=="jobc"){
      this.setState({jobcVal:[],timecVal:[],timefVal:[],timerVal:[],filterVisible9:false,filterVisible10:false,
    filterVisible11:false,filterVisible22:false,filterVisible23:false});
      this.clearJobFilters([],val);
    }else if(val=="timec"){
      this.setState({timecVal:[],timefVal:[],timerVal:[],filterVisible9:false,filterVisible10:false,
    filterVisible11:false,filterVisible22:false});
    }else if(val=="timef"){
      this.setState({timefVal:[],timerVal:[],filterVisible10:false,
    filterVisible11:false,filterVisible22:false});
    }else if(val=="timer"){
      this.setState({timerVal:[],filterVisible11:false,filterVisible22:false,values:[]});
    }else if(val=="org"){
      this.setState({orgVal:[],filterVisible21:false});
    }else if(val=="pft"){
      this.setState({pftVal:[],filterVisible22:false});
    }else{
      
    this.setState({divVal: [],divisionVal:[],regVal:[],mrktVal:[],gradeVal:[],jobVal:[],timecVal:[],timerVal:[],timefVal:[],storenumVal:[],deptVal:[],strvolVal:[],filterVisible:false,pftVal:[],filterVisible22:false,
    filterVisible1:false,filterVisible2:false,filterVisible3:false,filterVisible4:false,filterVisible5:false,filterVisible6:false,filterVisible7:false,filterVisible8:false,
    filterVisible9:false,jobcVal:[],filterVisible23:false,
    filterVisible10:false,filterVisible11:false,filterVisible20:false,filterVisible21:false,orgVal:[],filterCnt:[0],filterSel:["Filters Selected - All"]
  });
      this.loadFilters();
      // this.compFrame("","default");
    }
  }

  change(event,a){

    if(a=="div"){

     this.setState({divVal: event.target.value});


   }
   if(a=="division"){

     this.setState({divisionVal: event.target.value});


   }else if(a=="reg"){

     this.setState({regVal: event.target.value});

   }else if(a=="mrkt"){

     this.setState({mrktVal: event.target.value});

   } else if(a=="storenum"){

     this.setState({storenumVal: event.target.value});

   } else if(a=="dept"){

     this.setState({deptVal: event.target.value});

   }else if(a=="grade"){

     this.setState({gradeVal: event.target.value});

   }
   else if(a=="job"){

     this.setState({jobVal: event.target.value});

   }
   else if(a=="jobc"){

     this.setState({jobcVal: event.target.value});

   }
   else if(a=="timec"){

     this.setState({timecVal: event.target.value});

   }
   else if(a=="timef"){

     this.setState({timefVal: event.target.value});

   }
   else if(a=="timer"){

     this.setState({timerVal:this.state.timerVal});

   } 
   else if(a=="comp"){
     this.setState({compVal:  event.target.value});
   }
   else if(a=="hist"){
     this.setState({histVal:  event.target.value});
   }

   if(a =="div" || a=="division" || a=="reg" || a=="mrkt" || a=="storenum"){
    this.loadFilters2(event.target.value,a);
  }else if(a=="job" || a=="jobc"){
    this.loadPeople2(event.target.value,a);
  }
}; 

handleChange(values,name) {

if(name=="divVal"){

 var ac =equal(values, this.state.divVal);
 
 this.setState({divVal: values});
 
 if(ac==false){
  this.loadFilters2(values,"div");
 }
  
}else if(name=="divisionVal"){
var ac = equal(values, this.state.divisionVal);
 this.setState({divisionVal:values});
  if(ac==false)
  this.loadFilters2(values,"division")
}else if(name=="regVal"){
var ac = equal(values, this.state.regVal);
this.setState({regVal:values});
 if(ac==false)
  this.loadFilters2(values,"reg")
}else if(name=="mrktVal"){
var ac = equal(values, this.state.mrktVal);
 this.setState({mrktVal: values });
  if(ac==false)
  this.loadFilters2(values,"mrkt")
}else if(name=="strvolVal"){
var ac = equal(values, this.state.strvolVal);
 this.setState({strvolVal: values });
  if(ac==false)
  this.loadFilters2(values,"strvol")
}else if(name=="storenumVal"){
var ac = equal(values, this.state.storenumVal);
 this.setState({storenumVal: values });
  if(ac==false)
  this.loadFilters2(values,"storenum")
}else if(name=="deptVal"){
var ac = equal(values, this.state.deptVal);
 this.setState({deptVal: values });
  if(ac==false)
  this.loadFilters2(values,"dept")
}else if(name=="gradeVal"){
var ac = equal(values, this.state.gradeVal);
 this.setState({gradeVal: values });
  if(ac==false)
  this.loadPeople2(values,"grade")
}else if(name=="jobVal"){
var ac = equal(values, this.state.jobVal);
 this.setState({jobVal: values });
  if(ac==false)
  this.loadPeople2(values,"job")
}else if(name=="jobcVal"){
var ac = equal(values, this.state.jobcVal);
 this.setState({jobcVal: values });
  if(ac==false)
  this.loadPeople2(values,"jobc")
}else if(name=="timecVal"){
var ac = equal(values, this.state.timecVal);
 this.setState({timecVal: values });
  if(ac==false)
  this.loadPeople2(values,"timec")
}else if(name=="timefVal"){
var ac = equal(values, this.state.timefVal);
 this.setState({timefVal: values });
  if(ac==false)
  this.loadPeople2(values,"timef")
}else if(name=="timerVal"){
var ac = equal(values, this.state.timerVal);
 this.setState({timerVal: values });
  if(ac==false)
  this.loadPeople2(values,"timer")
}else if(name=="pftVal"){
 this.setState({pftVal: values });
 if(values.length >0){
  this.setState({filterVisible22:true,filterVisible:true});
  }else{
   this.setState({filterVisible22:false});
  }
}
 
} 

chkFilterCnt(){
  var that=this;
  if(this.state.showInputBox==true){
  document.getElementById("prefID").value="";
  this.setState({showInputBox:false});
  }
  axios.get('/chkFilter',{
    params: {
      vendorID:sessionStorage.vendor
    }
  })
  .then(res => {

    console.log(res);
    var count = res.data.count;
    var data = res.data.filterValues;
    var prefnm=[];
    if(count > 0){
        
        for(var i=0; i <data.length; i++){
            prefnm.push(data[i].name);
        }
        // this.props.downFlag=false;
        that.setState({showCombo:true,prefNames:prefnm,prefVal:data});
    }else{
      // this.props.downFlag=false;
       that.setState({prefNames:prefnm});
    }
    
    if(prefFlag == false){
  var prefNme;
  document.getElementById("preferVal").value="";
  prefNme="Preference";
    if(!prefnm.includes("Preference1")){
      prefNme="Preference1";
    }else if(!prefnm.includes("Preference2")){
      prefNme="Preference2";
    }else if(!prefnm.includes("Preference3")){
      prefNme="Preference3";
    }
  document.getElementById("preferVal").value=prefNme;
} 

  })

// }
}
dispInputBox(){
  this.chkFilterCnt();
var divVal1 =this.convertVal(this.state.divVal);
var divisionVal1 =this.convertVal(this.state.divisionVal);
var regVal1 =this.convertVal(this.state.regVal);
var mrktVal1 =this.convertVal(this.state.mrktVal);
var storenumVal1 =this.convertVal(this.state.storenumVal);
var strvolVal1 =this.convertVal(this.state.strvolVal);
var deptVal1 =this.convertVal(this.state.deptVal);
var jobVal1 =this.convertVal(this.state.jobVal);
var timecVal1 =this.convertVal(this.state.timecVal);
var timerVal1 =this.convertVal(this.state.timerVal);
var timefVal1= this.convertVal(this.state.timefVal);
var gradeVal1=this.convertVal(this.state.gradeVal);
var pftVal1=this.convertVal(this.state.pftVal);
var jobcVal1=this.convertVal(this.state.jobcVal);

 options = {
      'BUSINESS_UNIT' : divVal1 ? divVal1 : "",
      "Division" : divisionVal1 ? divisionVal1:"",
      'REGION_NAME' : regVal1 ? regVal1 : "",
      'MARKET_AREA_NAME' : mrktVal1 ? mrktVal1 : "",
      'STORE_NBR' : storenumVal1 ? storenumVal1 :"",
      'Store_Volume' : strvolVal1 ? strvolVal1:"",
      'Department':deptVal1 ? deptVal1 :"",
      'Grade_Level_grp' :gradeVal1 ? gradeVal1 :"",
      'Time in Facility Bucket' : timefVal1 ? timefVal1 :"",
      'Time in Role Bucket ' : timerVal1 ? timerVal1 :"",
      'Job_Family': jobVal1 ? jobVal1 :"",
      'Time in Company Bucket':timecVal1 ? timecVal1 :"",
      'PT_FT_Temp': pftVal1 ? pftVal1:"",
      "JOB_CODE":jobcVal1?jobcVal1:""
}

    var optKey = Object.keys(options);
    
    for(var i=0; i<optKey.length;i++){

        if(options[optKey[i]] == ""){

          delete options[optKey[i]];
        }
    }
    var keys_opt = Object.keys(options);
    
    if(keys_opt.length>0){
      var modal = document.getElementById('myModal1');
      document.getElementById('savePref').style.display="block";
       document.getElementById('preferVal').style.display="inline";
         document.getElementById('prefLabel').style.display="inline";
       
          var span = document.getElementsByClassName("close")[0];
          modal.style.display = "block";
          span.onclick = function() {
              modal.style.display = "none";
          }
          window.onclick = function(event) {
              if (event.target == modal) {
                  modal.style.display = "none";
              }
          }
          var dataArr=[];
           var a="";
for(var i=0; i<keys_opt.length;i++){
    var name="";
  a=options[keys_opt[i]];
  if(keys_opt[i] == "BUSINESS_UNIT"){
    name = "Business Unit";
}
if(keys_opt[i] == "REGION_NAME"){
    name = "Region";
}
if(keys_opt[i] == "MARKET_AREA_NAME"){
    name = "Market Area Name";
}
if(keys_opt[i] == "STORE_NBR"){
    name = "Store Number";
}
if(keys_opt[i] == "Store_Volume"){
    name = "Store Volume";
}
if(keys_opt[i] == "Grade_Level_grp"){
    name = "Grade Level";
}
if(keys_opt[i] == "Job_Family"){
    name = "Job Family";
}
if(keys_opt[i] == "PT_FT_Temp"){
    name = "PT/FT/Temp";
}
if(keys_opt[i] == "Time in Facility Bucket"){
    name = "Time in Facility";
}
if(keys_opt[i] == "Time in Role Bucket "){
    name = "Time in Role";
}
if(keys_opt[i] == "Time in Company Bucket"){
    name = "Time in Company";
}
if(keys_opt[i] == "JOB_CODE"){
    name = "Job Code";
}
  name = (name != "") ? name : keys_opt[i];
  dataArr.push([name]+" : "+a);
  }
 
  if(dataArr.length > 0){
    this.setState({prefValues:dataArr,prefCount:keys_opt.length});
  }

  
          
    }else{
      alert("Please select the filters");
   }

}

closeele(){
  document.getElementById("myModal1").style.display="none";
}

saveFilter(){

  

  if(this.state.prefCount>0){

  options["vendor"]=sessionStorage.vendor;
  var addData="new";
  var prefEditName;
  var prefNme;
  var pref1;
  var pref2;
  var pref3;
  if(prefFlag == true && prefName != ""){
    prefNme = prefName;
    addData="replace";
    prefEditName=document.getElementById("preferVal").value;
  }else{
    prefNme="Preference";
    if(!this.state.prefNames.includes("Preference1")){
      prefNme="Preference1";
    }else if(!this.state.prefNames.includes("Preference2")){
      prefNme="Preference2";
    }else if(!this.state.prefNames.includes("Preference3")){
      prefNme="Preference3";
    }
   var prefbox = document.getElementById("preferVal").value;
    if(prefbox != "" && prefbox != undefined){
      prefNme=prefbox;
    }
    
    if(this.state.prefNames.length==3){
      this.closeele();
      alert("You already have maximum(3) of Saved Preferences. Please delete/edit any one saved preference.");
      return;
  }
  if(this.state.prefNames.includes(prefNme)){
     alert("Name already exists. Please save your preference with different name");
     return;
  }
  }
   
  
  var comp="";
  for(var i=0; i<this.state.prefVal.length;i++){
    var opt=Object.assign({},this.state.prefVal[i]);
    delete opt["name"];
    comp =equal(options,opt);
    if(comp==true){
      this.closeele();
      alert("Preference already exists (" + this.state.prefVal[i]["name"] + ")")
      return;
    }
  }
  options["name"]=prefNme;
  axios.get('/saveFilter',{
    params: {
      value:options,
      prefName:prefNme,
      addData:addData,
      editName:prefEditName
    }
  })
  .then(res => {

    console.log(res);
    prefFlag=false;
    this.chkFilterCnt();
    alert("Your preference is saved !!");
    document.getElementById("preferVal").value="";
    document.getElementById("myModal1").style.display="none";
  })
  }
}

deleteFilter(e){
  e.stopPropagation();
  var conf="";
  if (confirm("Are you sure you want to delete ?")) {
        conf = "y";
    } else {
        conf = "n";
    }
    if(conf=="y"){
      var delName=e.currentTarget.parentElement.value;
      axios.get('/deleteFilter',{
          params: {
            value:sessionStorage.vendor,
            prefName:delName,
          }
        })
        .then(res => {

          console.log(res);
          prefFlag=false;
          this.chkFilterCnt();
        })
    }else{
      return;
    }
  }


popFilter(e){
  e.stopPropagation();
  var dispFlag="";
  if(e.currentTarget.className=="prefButton" || e.currentTarget.className=="prefButton prefButton1"){
    prefName=e.currentTarget.value;
    var modal = document.getElementById('myModal1');
    var span = document.getElementsByClassName("close")[0];
     document.getElementById('savePref').style.display="none";
       document.getElementById('preferVal').style.display="none";
        document.getElementById('prefLabel').style.display="none";
    modal.style.display = "block";
    span.onclick = function() {
        modal.style.display = "none";
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    
  }else{
    prefName=e.currentTarget.parentElement.value;
    // var ele = (document.getElementsByClassName("prefButton1").length !=0) ? document.getElementsByClassName("prefButton1")[0].classList.remove("prefButton1") :"";
    // e.currentTarget.parentElement.classList.add("prefButton1");
    document.getElementById("preferVal").value=prefName;
    this.clear(""); 
    prefFlag=true;
   this.closeFilterbox("alert");
    dispFlag="no";
    
  }

 
  
  axios.get('/getDefaultFilter',{
    params: {
      value:sessionStorage.vendor,
      prefName:prefName
    }
  })
  .then(res => {

    console.log(res);
    var data= res.data.dataFilter[0];
    delete data['name'];
    delete data['vendor']; 
    
    var a="";
    if(dispFlag=="no"){
    if(data["BUSINESS_UNIT"]){
      this.setState({divVal:this.conv(data["BUSINESS_UNIT"]),filterVisible1:true});
      
    }
    if(data["Department"]){
      this.setState({deptVal:this.conv(data["Department"]),filterVisible6:true});
    }
    if(data["Division"]){
      this.setState({divisionVal:this.conv(data["Division"]),filterVisible2:true});
    }
    if(data["Grade_Level_grp"]){
      this.setState({gradeVal:this.conv(data["Grade_Level_grp"]),filterVisible7:true});
    }
    if(data["Job_Family"]){
      this.setState({jobVal:this.conv(data["Job_Family"]),filterVisible8:true});
    }
    if(data["MARKET_AREA_NAME"]){
      this.setState({mrktVal:this.conv(data["MARKET_AREA_NAME"]),filterVisible4:true});
    }
    if(data["PT_FT_Temp"]){
      this.setState({pftVal:this.conv(data["PT_FT_Temp"]),filterVisible22:true});
    }
    if(data["REGION_NAME"]){
      this.setState({regVal:this.conv(data["REGION_NAME"]),filterVisible3:true});
    }
    if(data["STORE_NBR"]){
      this.setState({storenumVal:this.conv(data["STORE_NBR"]),filterVisible5:true});
    }
    if(data["Store_Volume"]){
      this.setState({strvolVal:this.conv(data["Store_Volume"]),filterVisible20:true});
    }
    if(data["Time in Company Bucket"]){
      this.setState({timecVal:this.conv(data["Time in Company Bucket"]),filterVisible9:true});
    }
    if(data["Time in Facility Bucket"]){
      this.setState({timefVal:this.conv(data["Time in Facility Bucket"]),filterVisible10:true});
    }
    if(data["Time in Role Bucket "]){
      this.setState({timerVal:this.conv(data["Time in Role Bucket "]),filterVisible11:true});
    }
    if(data["JOB_CODE"]){
      this.setState({jobcVal:this.conv(data["JOB_CODE"]),filterVisible23:true});
    }
    this.setState({div:res.data.bUnit,division:res.data.division,reg:res.data.region,mrkt:res.data.market,
    storenum:res.data.store,strvol:res.data.storeV,job:res.data.job,jobc:res.data.jobc,filterVisible:true});
    }else{
  delete data['vendor']; 
  var optKey = Object.keys(data);
  var dataArr=[];
  var filDef=["Filters Selected - All"];
  for(var i=0; i<optKey.length;i++){
    var name="";
  a=data[optKey[i]];
  if(optKey[i] == "BUSINESS_UNIT"){
    name = "Business Unit";
}
if(optKey[i] == "REGION_NAME"){
    name = "Region";
}
if(optKey[i] == "MARKET_AREA_NAME"){
    name = "Market Area Name";
}
if(optKey[i] == "STORE_NBR"){
    name = "Store Number";
}
if(optKey[i] == "Store_Volume"){
    name = "Store Volume";
}
if(optKey[i] == "Grade_Level_grp"){
    name = "Grade Level";
}
if(optKey[i] == "Job_Family"){
    name = "Job Family";
}
if(optKey[i] == "PT_FT_Temp"){
    name = "PT/FT/Temp";
}
if(optKey[i] == "Time in Facility Bucket"){
    name = "Time in Facility";
}
if(optKey[i] == "Time in Role Bucket "){
    name = "Time in Role";
}
if(optKey[i] == "Time in Company Bucket"){
    name = "Time in Company";
}
if(optKey[i] == "JOB_CODE"){
    name = "Job Code";
}
  name = (name != "") ? name : optKey[i];
  dataArr.push([name]+" : "+a);
  }
 
  if(dataArr.length > 0){
    this.setState({prefValues:dataArr});
  }else{
    // this.setState({filterSel:filDef});
  }
  // this.setState({filterCnt:optKey.length});
    }
 })
}

loadTimeframe(val){

   
  axios.get('/timeFrame',{
    params: {
      comp : val,
      
    }
  })
  .then(res => {
    const posts = res.data;
    var p2pdata=[];
    var p2pdata1=[];
    var p2pdata2=[];
    var p2pdata3=[];
    var qtrdata=[];
    var maxvalue = Math.max.apply(null, res.data.yearVal);
     var minvalue = Math.min.apply(null, res.data.yearVal);
    //  yearVal.push(minvalue);
    //  yearVal.push(maxvalue);
     this.setState({timeframe:yearVal});
    
    for(var i=0; i < res.data.yearVal.length; i++){
      yeardata=res.data.yearVal;

      if(res.data.p2p1[res.data.yearVal[i]]){
         p2pdata[i]= res.data.p2p1[res.data.yearVal[i]];
      }
       if(res.data.p2p2[res.data.yearVal[i]]){
         p2pdata1[i]= res.data.p2p2[res.data.yearVal[i]];
      }
      if(res.data.p2p3[res.data.yearVal[i]]){
         p2pdata2[i]= res.data.p2p3[res.data.yearVal[i]];
      }
      if(res.data.p2p4[res.data.yearVal[i]]){
         p2pdata3[i]= res.data.p2p4[res.data.yearVal[i]];
      }
      if(res.data.qtr1[res.data.yearVal[i]]){
         qtrdata[i]= res.data.qtr1[res.data.yearVal[i]];
      }


    }

   

if(res.data.yearVal.length==4){

  this.setState({qtr:qtrdata[0].reverse(),qtr1:qtrdata[1].reverse(),qtr2:qtrdata[2].reverse(),qtr3:qtrdata[3].reverse()});
}
if(res.data.yearVal.length==3){

  yeardata[3]="";
  this.setState({qtr:qtrdata[0],qtr1:qtrdata[1],qtr2:qtrdata[2],qtr3:[]});
  // this.setState({p2p1:p2pdata[0].reverse(),p2p2:p2pdata[1].reverse(),p2p3:p2pdata[2].reverse(),p2p4:[]});
}
if(res.data.yearVal.length==2){
  yeardata[3]="";
  yeardata[2]="";

  this.setState({qtr:qtrdata[0],qtr1:qtrdata[1],qtr2:[],qtr3:[]});
  // this.setState({p2p1:p2pdata[0].reverse(),p2p2:p2pdata[1].reverse(),p2p3:[],p2p4:[]});
}
if(res.data.yearVal.length==1){
  yeardata[3]="";
  yeardata[2]="";
  yeardata[1]="";

  this.setState({qtr:qtrdata[0],qtr1:[],qtr2:[],qtr3:[]});
  // this.setState({p2p1:p2pdata[0].reverse(),p2p2:[],p2p3:[],p2p4:[]});
}
if(res.data.yearVal.length==0){
   yeardata[3]="";
  yeardata[2]="";
  yeardata[1]="";
   yeardata[0]="";


  this.setState({qtr:[],qtr1:[],qtr2:[],qtr3:[]});
  // this.setState({p2p1:[],p2p2:[],p2p3:[],p2p4:[]});
}
this.setState({p2p1:(p2pdata[0] ? p2pdata[0].reverse() : []),
    p2p2:(p2pdata[1] ? p2pdata[1].reverse() : []),
    p2p3:(p2pdata[2] ? p2pdata[2].reverse() : []),
    p2p4:(p2pdata[3] ? p2pdata[3].reverse() : [])});
  this.setState({p2p1_1:(p2pdata1[0] ? p2pdata1[0].reverse():[]),
    p2p2_1:(p2pdata1[1] ? p2pdata1[1].reverse() :[]),
    p2p3_1:(p2pdata1[2] ? p2pdata1[2].reverse():[]),
    p2p4_1:(p2pdata1[3] ? p2pdata1[3].reverse() : [])});
  this.setState({p2p1_2:(p2pdata2[0] ? p2pdata2[0].reverse():[]),
    p2p2_2:(p2pdata2[1] ? p2pdata2[1].reverse() :[]),
    p2p3_2:(p2pdata2[2] ? p2pdata2[2].reverse():[]),
    p2p4_2:( p2pdata2[3] ? p2pdata2[3].reverse():[])});
  this.setState({p2p1_3:(p2pdata3[0] ? p2pdata3[0].reverse():[]),
    p2p2_3:(p2pdata3[1] ? p2pdata3[1].reverse() : []),
    p2p3_3:( p2pdata3[2] ? p2pdata3[2].reverse() : []),
    p2p4_3:(p2pdata3[3] ? p2pdata3[3].reverse() : [])});
// this.compFrame("","default");
    
  });
}

menuItems(name) {

  if(name=="divVal"){
 return this.state.div.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="divisionVal"){
 return this.state.division.map((name) => (
 <div value={name}>{name}</div>
  ));
}else if(name=="regVal"){
return this.state.reg.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="mrktVal"){
return this.state.mrkt.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="strvolVal"){
return this.state.strvol.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="storenumVal"){
return this.state.storenum.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="deptVal"){
return this.state.dept.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="gradeVal"){
return this.state.grade.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="jobVal"){
return this.state.job.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="jobcVal"){
return this.state.jobc.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="timecVal"){
 return this.state.timec.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="timefVal"){
return this.state.timef.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="timerVal"){
return this.state.timer.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}else if(name=="pftVal"){
return this.state.pft.map((name) => (
 <div key={name} value={name}>{name}</div>
  ));
}

}


selectionRenderer(values, hintText, name) {


   
    if (!values) return hintText
    const { value, label } = values
    if (Array.isArray(values)) {
    if(values.length ==1){
    return values[0].value ? values[0].value : values[0]
    }else{
      return values.length
       ? 'Multiple values' : hintText
    }
    }
    else if (label || value) return label || value
    else return hintText
  }

hidemenu(Menuname){
  var x;
  if (Menuname!="blank"){
      counter=counter+1;
      if (Menuname=="Segments") {
      x=document.getElementById("SegmentMenu");
      if(document.getElementById("PeopleMenu")!==null){ document.getElementById("PeopleMenu").style.display = 'none';}
      if(document.getElementById("TimeFrameMenu")!==null){document.getElementById("TimeFrameMenu").style.display = 'none';}
      if(document.getElementById("ComparisonFrameMenu")!==null){document.getElementById("ComparisonFrameMenu").style.display = 'none';}
       if(document.getElementById("FilterMenu")!==null){document.getElementById("FilterMenu").style.display = 'none';}
       if(this.state.measure==true){
       this.setState({measure:false,isCollapse:true});
       }
       s_flag=true;
       p_flag=false;

      }
      else if (Menuname=="People") {
      x=document.getElementById("PeopleMenu");        
      if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'none';}
      if(document.getElementById("TimeFrameMenu")!==null){document.getElementById("TimeFrameMenu").style.display = 'none';}
       if(document.getElementById("FilterMenu")!==null){document.getElementById("FilterMenu").style.display = 'none';}
      if(document.getElementById("ComparisonFrameMenu")!==null){document.getElementById("ComparisonFrameMenu").style.display = 'none';}
      if(this.state.measure==true){
       this.setState({measure:false,isCollapse:true});
       }
       s_flag=false;
       p_flag=true;
      } 
      else if (Menuname=="TimeFrame") {
      x=document.getElementById("TimeFrameMenu");      
      if(document.getElementById("PeopleMenu")!==null){document.getElementById("PeopleMenu").style.display = 'none';}
      if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'none';}
       if(document.getElementById("FilterMenu")!==null){document.getElementById("FilterMenu").style.display = 'none';}
      if(document.getElementById("ComparisonFrameMenu")!==null){document.getElementById("ComparisonFrameMenu").style.display = 'none';}
      countEle=0;
      document.getElementById("timed").style.backgroundColor="#76b9e6";
      if(yearVal.length !=0 && yearVal.length ==2){
      this.compbg();
      }
      else{
        this.compFrame("","clear")
      }
      // if(timeCount ==0){
      // document.getElementById("ptpbuttonY").classList.add("bgCol");
      // document.getElementById("ptpbuttonQ").classList.remove("bgCol");
      // document.getElementById("ptpbuttonP").classList.remove("bgCol");
      //   var abc = yeardata;
      //   var a = abc.indexOf(yearVal[0]);
      //   var b = abc.indexOf(yearVal[1]);
      //   var interVal = abc.slice(a, b+1);
      //   for(var i=0;i<interVal.length;i++){

      //     document.getElementById(interVal[i]).parentNode.children[0].classList.add("bgCol");

      //   }
      // // this.compFrame("","default");
      // timeCount++;
      // count=2;
     
      // }else{
      //   if(yearVal.length !=0){
      //   this.compbg();
      //   }
      // }
      } 
      else if (Menuname=="ComparisonFrame") {
      x=document.getElementById("ComparisonFrameMenu");        
      if(document.getElementById("PeopleMenu")!==null){document.getElementById("PeopleMenu").style.display = 'none';}
      if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'none';}
      if(document.getElementById("TimeFrameMenu")!==null){document.getElementById("TimeFrameMenu").style.display = 'none';}
       if(document.getElementById("FilterMenu")!==null){document.getElementById("FilterMenu").style.display = 'none';}
      } 
      else if (Menuname=="FilerApplied") {
      x=document.getElementById("FilterMenu");        
      if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'none';}
      if(document.getElementById("TimeFrameMenu")!==null){document.getElementById("TimeFrameMenu").style.display = 'none';}
      if(document.getElementById("PeopleMenu")!==null){document.getElementById("PeopleMenu").style.display = 'none';}
      if(document.getElementById("ComparisonFrameMenu")!==null){document.getElementById("ComparisonFrameMenu").style.display = 'none';}
      if(x.style.display=="none"){
      document.getElementById("filcls").classList.remove("clsHeader");
      document.getElementById("filcls").style.color="white";
       document.getElementById("filcur").classList.add("clsHeader");
       this.chkFilterCnt();
      }else{
        document.getElementById("filcls").classList.add("clsHeader");
        document.getElementById("filcur").classList.remove("clsHeader");
      } 
      }else if (Menuname=="exeCollapse"){
          
          if(this.state.isCollapse==true){
            if(s_flag==true && p_flag ==false){
             if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'block';}
             if(document.getElementById("PeopleMenu")!==null){document.getElementById("PeopleMenu").style.display = 'none';}
            }
             if(s_flag==false && p_flag ==true){
             if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'none';}
          if(document.getElementById("PeopleMenu")!==null){document.getElementById("PeopleMenu").style.display = 'block';}
            }
          this.setState({measure:false,isCollapse:true});
          }else{
            if(document.getElementById("SegmentMenu")!==null){document.getElementById("SegmentMenu").style.display = 'none';}
          if(document.getElementById("PeopleMenu")!==null){document.getElementById("PeopleMenu").style.display = 'none';}
            this.setState({measure:true,isCollapse:false});
          }
          
      }           
    if(x!=undefined && x!=null&& x.style.display=='block'){
      x.style.display='none';
     if(this.state.isCollapse==true){
       this.setState({measure:true,isCollapse:false});
       }
    }
    else  if(x!=undefined && x!=null){
      x.style.display='block';
    }

}else if(Menuname=="blank")
   {  

        if(document.getElementById("TimeFrameMenu")!==null){
          document.getElementById("TimeFrameMenu").style.display = 'none';
         
        }

     

        counter=0;
     
    }
}
  


render() {
 const {divVal,divisionVal,regVal,mrktVal,storenumVal,orgVal,deptVal,gradeVal,jobVal,jobcVal,timecVal,timefVal,timerVal,strvolVal,pftVal,comprVal} = this.state;

 const props = this.props;
 const handleClick = this.handleClick; 

 return (
 <div className="sidebar"> 
 <div className="container">
<div id="aside-menu-wrapper">
                <div className="logo"><img src="./img/wlogo.png" className="logo" onClick={(e)=>this.hidemenu("blank")} style={{height:"10vh",padding:"0 0 30px 0px"}}></img></div>
                <div className="aside-menu-tab">
                <ul id="style1"  onClick={(e)=>this.hidemenu("blank")}>
                  <li>
                  <p><span className="clsHeader" id="filcls">Filters({this.state.filterCnt})</span>  |&nbsp;
                
                  <span className="FilerApplied" style={{cursor:'pointer',color:'white'}} id="filcur">
                  <span onClick={(e)=>this.hidemenu("FilerApplied")} id="filterApp">Current Selection <i id="filterApp1" className="fa fa-info-circle" aria-hidden="true"></i></span>
                  <ul id="FilterMenu" style={{display:'none'}}>
                 
                  <div style={{height:'47vh',position: 'fixed',zIndex:1,backgroundColor:'#96C9EA',color:'#fff',marginTop:'2px',textAlign:'left'}}
                  id="filterDiv"> 
                   <div><i style={{'margin':'8px','fontSize': '1vw','float':'right'}}  onClick={(e)=>this.closeFilterbox("")} className="fa fa-window-close fa-2x" aria-hidden="true"></i></div>
                  <div style={{'padding':'1vw'}}> 
                  { this.state.filterSel.map((name) => (
                  <div key={name} value={name}>{name} <br/><br/></div>
                    ))}
                  </div>
                  <hr style={{borderTop:'none'}}/>
                    <button style={{'margin':'12px'}} className="ptpbuttonFil" onClick={(e)=>this.dispInputBox()}> Save </button>
                   

                   <div style={{'display':'inline-grid'}}> 
                   {this.state.prefNames.map((name) => (
                    <button value={name} style={{'width':'12vw'}} className="prefButton" onClick={(e)=>this.popFilter(e)}>
                    <i className="fa fa-check-circle prefIcon"  style={{'float':'left'}} onClick={(e)=>this.loadDashboardPref(e)}></i>
                    {name}
                    <i className="fa fa-trash-o delFil prefIcon"  onClick={(e)=>this.deleteFilter(e)}></i>
                    <i className="fa fa-edit editFil prefIcon"  onClick={(e)=>this.popFilter(e)}></i>
                    </button>
                   ))}
                   </div>
                  
                    </div>
                  </ul>
                </ span>
                </p>
                  </li>
                   <li>  {
                      this.state.filterVisible
                      ? <span id="filterReset"> <br></br><i className="fa fa-filter curPntr" aria-hidden="true"><span onClick={(e)=>this.clear()}> <i className="fa fa-times filterOpt"></i> Reset all</span></i> </span>
                      : null
                    } </li>
                    </ul>
                </div>
                
                {this.state.measure ? <div style={styles1.block} className="measureNames"><span className="measuretitle"> Measure Names</span>
                  
                  <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="All"
                    checked={this.state.checkedA}
                    onCheck={this.updateCheck.bind(this,"all")}
                    style={styles1.checkbox}
                    labelStyle={{color:'black'}}
                    iconStyle={{fill:'white'}}
                    
                  />
                    </MuiThemeProvider>
                  <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="Headcount"
                    checked={this.state.checked}
                    onCheck={this.updateCheck.bind(this,0)}
                    style={styles1.checkbox}
                    labelStyle={{color:'black'}}
                    iconStyle={{fill:'white'}}
                    
                  />
                    </MuiThemeProvider>
                  <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="Exit"
                    checked={this.state.checked1}
                    onCheck={this.updateCheck.bind(this,1)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                   <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="Turnover"
                    checked={this.state.checked2}
                    onCheck={this.updateCheck.bind(this,2)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                   <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="Vacancy"
                    checked={this.state.checked3}
                    onCheck={this.updateCheck.bind(this,3)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                   <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="Open Req"
                    checked={this.state.checked4}
                    onCheck={this.updateCheck.bind(this,4)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                   <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="4+ Absenteeism"
                    checked={this.state.checked5}
                    onCheck={this.updateCheck.bind(this,5)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                   <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="9+ Absenteeism"
                    checked={this.state.checked7}
                    onCheck={this.updateCheck.bind(this,7)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                   <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                  <Checkbox
                    label="AB PT Turnover"
                    checked={this.state.checked6}
                    onCheck={this.updateCheck.bind(this,6)}
                    style={styles1.checkbox}
                     labelStyle={{color:'black'}}
                      iconStyle={{fill:'white'}}
                  />
                  </MuiThemeProvider>
                </div> : null}
                <ul className="style1">
              

                {this.state.isCollapse  ?    <li>                    
                    <a>Measure Names</a>
                </li> : null }
                
              {this.state.isHome  ?    <li>                    
                    <a onClick={(e)=>this.hidemenu("Segments")}>Segments <i className="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul id="SegmentMenu"  className="addSize" style={{display:'none'}}>
                      <li>
                        <label >Business Unit</label>
                         <span  onClick={(e)=>this.clear("div")}> {
                            this.state.filterVisible1
                            ? <FilterIcon />
                            : null
                          } </span>
                          <div className="leftoption">
                          <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                          <SuperSelectField
                          name="divVal"
                          multiple
                          checkPosition='left'
                          hintText='All'
                          value={divVal}
                          onChange= {this.handleChange}
                           selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'divVal')}                          
                          style={{ width: 'auto', overflowY:'hidden'}}
                          menuStyle={{width:'auto',color:'black',fontSize:'10px',overflowY:'hidden'}}
                          innerDivStyle={{color:'black',fontSize:'10px', overflowY:'hidden'}}
                          selectedMenuItemStyle={{color:'black',fontSize:'10px', overflowY:'hidden'}}
                          hintTextAutocomplete="Search"
                          >

                          {this.menuItems('divVal')}
                                   
                          </SuperSelectField>
                          </MuiThemeProvider>
                          </div>
                        </li>

                        <li>
                        <label htmlFor="cb3">Division</label>
                         <span  onClick={(e)=>this.clear("division")}> 
                         {
                            this.state.filterVisible2
                            ? <FilterIcon />
                            : null
                          } </span>
                         <div className="leftoption">
                          <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                          <SuperSelectField
                          name="divisionVal"
                          multiple
                          checkPosition='left'
                          hintText='All'
                          value={divisionVal}
                          onChange= {this.handleChange}
                           selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'divisionVal')}
                          hintTextAutocomplete="Search"
                          style={{ width: 'auto'}}
                          menuStyle={{width:'auto'}}
                          selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                          
                          innerDivStyle={{color:'black',fontSize:'10px'}}

                          >

                          {this.menuItems('divisionVal')}
                                   
                          </SuperSelectField>
                          </MuiThemeProvider>
                          </div>
                        </li>

                        <li>
                        <label htmlFor="cb4">Region</label>
                         <span  onClick={(e)=>this.clear("reg")}> {
                            this.state.filterVisible3
                            ? <FilterIcon />
                            : null
                          } </span>
                         <div className="leftoption">
                          <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                          <SuperSelectField
                          name="regVal"
                          multiple
                          checkPosition='left'
                          hintText='All'
                          value={regVal}
                          onChange= {this.handleChange}
                           selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'regVal')}
                           hintTextAutocomplete="Search"                          
                          style={{ width: 'auto'}}
                          menuStyle={{width:'auto'}}
                          
                          selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                          innerDivStyle={{color:'black',fontSize:'10px'}}
                          hintTextAutocomplete="Search"
                          >

                          {this.menuItems('regVal')}
                                   
                          </SuperSelectField>
                          </MuiThemeProvider>
                          </div>
                        </li>

                        <li>
                        <label htmlFor="cb5">Market Area Name</label>
                         <span  onClick={(e)=>this.clear("mrkt")}> {
                            this.state.filterVisible4
                            ? <FilterIcon />
                            : null
                          } </span>
                         <div className="leftoption">
                          <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                          <SuperSelectField
                          name="mrktVal"
                          multiple
                          checkPosition='left'
                          hintText='All'
                          value={mrktVal}
                          onChange= {this.handleChange}
                           selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'mrktVal')}
                           hintTextAutocomplete="Search"                          
                          style={{ width: 'auto'}}
                          menuStyle={{width:'auto'}}
                          
                          selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                          innerDivStyle={{color:'black',fontSize:'10px'}}
                          >

                          {this.menuItems('mrktVal')}
                                   
                          </SuperSelectField>
                          </MuiThemeProvider> 
                          </div>
                        </li>

                        <li>
                        <label htmlFor="cb6">Store Volume</label>
                        <span  onClick={(e)=>this.clear("strvol")}> {
                          this.state.filterVisible20
                          ? <FilterIcon />
                          : null
                        } </span>
                         <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="strvolVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={strvolVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'strvolVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('strvolVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                        </li>

                        <li>
                        <label htmlFor="cb7">Store Number</label>
                        <span  onClick={(e)=>this.clear("storenum")}> {
                          this.state.filterVisible5
                          ? <FilterIcon />
                          : null
                        } </span>
                         <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="storenumVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={storenumVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'storenumVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('storenumVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                        </li>

                        <li>
                          <label htmlFor="cb8">Department</label>
                          <span  onClick={(e)=>this.clear("dept")}> {
                            this.state.filterVisible6
                            ? <FilterIcon />
                            : null
                          } </span>
                           <div  className="leftoption" style={{border:0}}>
                            <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                            <SuperSelectField
                            name="deptVal"
                            multiple
                            checkPosition='left'
                            hintText='All'
                            value={deptVal}
                            onChange= {this.handleChange}
                             selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'deptVal')}
                            hintTextAutocomplete="Search"
                            style={{ width: 'auto'}}
                            menuStyle={{width:'auto'}}
                            
                            selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                            innerDivStyle={{color:'black',fontSize:'10px'}}
                            >

                            {this.menuItems('deptVal')}
                                     
                            </SuperSelectField>
                            </MuiThemeProvider>
                            </div>
                        </li>

                   
                    </ul>
              </li> : null }

                    <li>
                    <a onClick={(e)=>this.hidemenu("People")}>People <i className="fa fa-angle-down" aria-hidden="true"></i></a>
                    <ul id="PeopleMenu" className="addSize" style={{display:'none'}}>
                      <li>
                        <label htmlFor="cb9">Grade Level</label>
                          <span  onClick={(e)=>this.clear("grade")}> {
                            this.state.filterVisible7
                            ? <FilterIcon />
                            : null
                          } </span>
                          <div className="leftoption">
                          <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                          <SuperSelectField
                          name="gradeVal"
                          multiple
                          checkPosition='left'
                          hintText='All'
                          value={gradeVal}
                          onChange= {this.handleChange}
                           selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'gradeVal')}
                          hintTextAutocomplete="Search"
                          style={{ width: 'auto'}}
                          menuStyle={{width:'auto'}}
                          
                          selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                          innerDivStyle={{color:'black',fontSize:'10px'}}
                          >

                          {this.menuItems('gradeVal')}
                                   
                          </SuperSelectField>
                          </MuiThemeProvider>
                          </div>
                      </li>

                        <li>
                        <label htmlFor="cb10">Job Family</label>
                         <span  onClick={(e)=>this.clear("job")}> {
                          this.state.filterVisible8
                          ? <FilterIcon />
                          : null
                        } </span>
                        <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="jobVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={jobVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'jobVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('jobVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                        </li>

                        <li>
                        <label htmlFor="cb15">Job Code</label>
                         <span  onClick={(e)=>this.clear("jobc")}> {
                          this.state.filterVisible23
                          ? <FilterIcon />
                          : null
                        } </span>
                        <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="jobcVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={jobcVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'jobcVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('jobcVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                        </li>

                       {this.state.isHome ? <li>
                        <label htmlFor="cb11">Time in Company</label>
                         <span  onClick={(e)=>this.clear("timec")}> {
                          this.state.filterVisible9
                          ? <FilterIcon />
                          : null
                        } </span>
                        <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="timecVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={timecVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'timecVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('timecVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                       </li> : null }

                      {this.state.isHome ?  <li>
                        <label htmlFor="cb12">Time in Facility</label>
                         <span  onClick={(e)=>this.clear("timef")}> {
                            this.state.filterVisible10
                            ? <FilterIcon />
                            : null
                          } </span>
                        <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="timefVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={timefVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'timefVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('timefVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                      </li> : null}

                       {this.state.isHome ? <li>
                        <label htmlFor="cb13">Time in Role</label>
                        <span  onClick={(e)=>this.clear("timer")}> {
                          this.state.filterVisible11
                          ? <FilterIcon />
                          : null
                        } </span>
                        <div className="leftoption">
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="timerVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={timerVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'timerVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('timerVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                        </li> : null }

                        <li>
                        <label htmlFor="cb14">PT/FT/Temp</label>
                        <span  onClick={(e)=>this.clear("pft")}> {
                          this.state.filterVisible22
                          ? <FilterIcon />
                          : null
                        } </span>
                        <div className="leftoption" style={{border:0}}>
                        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                        <SuperSelectField
                        name="pftVal"
                        multiple
                        checkPosition='left'
                        hintText='All'
                        value={pftVal}
                        onChange= {this.handleChange}
                         selectionsRenderer={(values, hintText) => this.selectionRenderer(values, hintText, 'pftVal')}
                        hintTextAutocomplete="Search"
                        style={{ width: 'auto'}}
                        menuStyle={{width:'auto'}}
                        
                        selectedMenuItemStyle={{color:'black',fontSize:'10px'}}
                        innerDivStyle={{color:'black',fontSize:'10px'}}
                        >

                        {this.menuItems('pftVal')}
                                 
                        </SuperSelectField>
                        </MuiThemeProvider>
                          </div>
                        </li>



                   
                    </ul>
                    

                  </li>
                            {this.state.comprEn ?<li className="TimeFrame nav-item nav-dropdown aa1" id="colTime">
                  <a onClick={(e)=>this.hidemenu("TimeFrame")} id="timed">Time Frame<i className="fa fa-angle-down" aria-hidden="true" id="timed1"></i></a>
                  <ul id="TimeFrameMenu" style={{display:'none'}}>
                  <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}  style={{display:'none'}}>
                  <div style={{height:'272px',position: 'fixed',zIndex:1}}
                  className={this.state.displayopt ? '' : 'd-none'} id="hideDiv">

                  <br/>
                  <div>
                        <p style={{'position': 'absolute',fontSize:'15px',marginLeft:'5px',marginTop:'11px',fontWeight:'bold'}}  >  Select Comparison Type: </p>
                       <button id="ptpbuttonY"  onClick={(e)=>this.compFrame(e,"Year")}> Year to Year       </button>
                       <button id="ptpbuttonQ" className=""  onClick={(e)=>this.compFrame(e,"Quarter")}> Quarter to Quarter </button>
                       <button id="ptpbuttonP"  onClick={(e)=>this.compFrame(e,"Period")}>  Period to Period </button>
                       <div className="vl"></div>
                        <span className="datelabel" id="startDate">Start Date:</span> <TextField
                        id="text-field-controlled"
                         style={{color:'white',width:'80px',}}
                        value={this.state.actualVal0 ? this.state.actualVal0 : ""}
                        disabled={true}
                        />

                        <span className="datelabel">End Date:</span><TextField
                        id="text-field-controlled"
                        style={{color:'white',width:'80px'}}
                         value={this.state.actualVal1 ? this.state.actualVal1 : ""}
                        disabled={true}
                        />

                        <button className="ptpbuttonApp" id="ptpbuttonApply" onClick={(e)=>this.loadDashboard()}> Apply </button>
                        <button className="ptpbutton" id="ptpbuttonClear" onClick={(e)=>this.compFrame(e,"clear")}> Clear </button> 
                  </div>
                      
                  <br/>
                  <hr style={{borderTop: '1px solid white'}}/>
                       <p style={{'position': 'absolute',marginTop: '5px',fontSize:'medium',marginLeft:'5px',fontWeight:'bold'}}>Select Time Frame: <br/>
                       <span style={{fontSize:'small'}}>(Fiscal Time Frame)</span></p>
                   {this.state.showyr ?   <div className="ptpyear" style={{display: 'inline',marginLeft:'143px'}}>
                      <IconButton tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px'}}>
                      <RaisedButton  label={yeardata[0]} style={{'margin':'5px 10px 0 0'}} className = "wAuto" 
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} value={yeardata[0]} id={yeardata[0]}
                      onClick={(e)=>this.year(e,yeardata[0])} disabled={this.state.yearDis} onMouseOver={(e)=>this.getHoverDate("Year",yeardata[0])}/>
                      </IconButton>
                      </div> : null}

                     {this.state.showyr ? <div className="ptpyear" style={{display: 'inline',marginLeft:'177px'}}>
                      <IconButton tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px'}}>
                      <RaisedButton  label={yeardata[1]} style={{'margin':'5px 10px 0 0'}} className = "wAuto" id={yeardata[1]}
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}}  labelColor ={"white"}
                      disabled={this.state.yearDis}  onClick={(e)=>this.year(e,yeardata[1])} onMouseOver={(e)=>this.getHoverDate("Year",yeardata[1])}/>
                      </IconButton> 
                      </div>  : null}
                      
                     {this.state.showyr ? <div className="ptpyear"  style={{display: 'inline',marginLeft:'170px'}}>
                      <IconButton tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px'}}>
                      <RaisedButton  label={yeardata[2]} style={{'margin':'5px 10px 0 0'}} className = "wAuto" id={yeardata[2]}
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}}   labelColor ={"white"}
                      disabled={this.state.yearDis} onClick={(e)=>this.year(e,yeardata[2])}
                      onMouseOver={(e)=>this.getHoverDate("Year",yeardata[2])}/>
                      </IconButton>
                      </div> : null}

                       {this.state.showyr ? <div className="ptpyear"  style={{display: 'inline',marginLeft:'172px'}}>
                       <IconButton tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px'}}>
                      <RaisedButton  label={yeardata[3]} style={{'margin':'5px 10px 0 0'}} className = "wAuto" id={yeardata[3]}
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} backgroundColor={this.state.bgColor}  labelColor ={"white"}
                      disabled={this.state.yearDis} onClick={(e)=>this.year(e,yeardata[3])}
                       onMouseOver={(e)=>this.getHoverDate("Year",yeardata[3])}/>
                        </IconButton>
                      </div>  : null}                                                             
                      
                      <br/>

                       {this.state.showqtr ?<div style={{display: 'inline-grid',marginLeft: '145px'}}>
                       {this.state.qtr.map((name) => (
                         <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px',backgroundColor: 'transparent'}}>
                          <RaisedButton  label={name.split("-")[1]} value={name}   onClick={(e)=>this.year(e,{name})} style={{'margin':'0 10px 2px 0'}} className = "wAuto"
                           buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.qtrDis}
                           onMouseOver={(e)=>this.getHoverDate("Quarter",name)}/>
                          </IconButton>
                         ))}
                      </div> : null}

                   {this.state.showprd ? <div className="ptpperiod" style={{display: 'inline-table',width:'210px'}}>
                          <div style={{display: 'inline'}}>
                           {this.state.p2p1.map((name) => (
                             <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                              <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'5px 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                              buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                               onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                            </IconButton>                                
                             ))} 
                             </div>
                             <div>
                              {this.state.p2p1_1.map((name) => (
                             <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                              <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'5px 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                              buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                               onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                            </IconButton>                                
                             ))} 
                             </div>
                             <div>
                              {this.state.p2p1_2.map((name) => (
                             <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                              <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'5px 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                              buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                               onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                            </IconButton>                                
                             ))} 
                             </div>
                             <div>
                              {this.state.p2p1_3.map((name) => (
                             <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                              <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'5px 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                              buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                               onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                            </IconButton>                                
                             ))}
                          </div>
                    </div>   : null }                   

                    {this.state.showqtr ? <div id="quarterid1" className="voidclass" style={{display: 'inline-grid',marginLeft: '-27px'}}>
                     {this.state.qtr1.map((name) => (
                       <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                        <RaisedButton  label={name.split("-")[1]} value={name} backgroundColor={this.state.bgColor}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 10px 2px 0'}} className = "wAuto"
                        buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.qtrDis}
                        onMouseOver={(e)=>this.getHoverDate("Quarter",name)}/>
                        </IconButton>
                       ))}
                    </div> : null}

                  {this.state.showprd ?<div className="ptpperiod" style={{display: 'inline-table',width:'210px'}}>
                  <div style={{display: 'inline'}}>

                   {this.state.p2p2.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','width':'13px','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>/>
                      </IconButton>
                     ))}
                     </div>
                     <div>
                     {this.state.p2p2_1.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','width':'13px','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>/>
                      </IconButton>
                     ))}
                     </div>
                     <div>
                     {this.state.p2p2_2.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','width':'13px','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>/>
                      </IconButton>
                     ))}
                     </div>
                     <div>
                     {this.state.p2p2_3.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','width':'13px','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>/>
                      </IconButton>
                     ))}
                     </div>
                  
                  </div>  : null}                       
                    
                     {this.state.showqtr ?<div id="quarterid2" className="voidclass" style={{display: 'inline-grid',marginLeft: '-27px'}}>
                     {this.state.qtr2.map((name) => (
                       <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                        <RaisedButton  label={name.split("-")[1]} value={name}   onClick={(e)=>this.year(e,{name})} style={{'margin':'0 10px 2px 0'}} className = "wAuto"
                        buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.qtrDis}
                        onMouseOver={(e)=>this.getHoverDate("Quarter",name)}/>
                        </IconButton>
                       ))}
                    </div>: null}

                  {this.state.showprd ?<div className="ptpperiod" style={{display: 'inline-table',width:'210px'}}>
                  <div style={{display: 'inline','wordWrap':'break'}}>
                   {this.state.p2p3.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                      onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                      </IconButton>
                     ))
                    }
                    </div>
                    <div>
                     {this.state.p2p3_1.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                      onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                      </IconButton>
                     ))
                    }
                     </div>
                    <div>
                    {this.state.p2p3_2.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                      onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                      </IconButton>
                     ))
                    }
                     </div>
                    <div>
                    {this.state.p2p3_3.map((name) => (
                     <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                      onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                      </IconButton>
                     ))
                    }
                   
                  </div>
                  </div>   :null}                  

                      
                    {this.state.showqtr ? <div id="quarterid3" className="voidclass"  style={{display: 'inline-grid',marginLeft: '-24px'}}>
                     {this.state.qtr3.map((name) => (
                        <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                        <RaisedButton  label={name.split("-")[1]} value={name} backgroundColor={this.state.bgColor}  onClick={(e)=>this.year(e,{name})} style={{'margin':'0 10px 2px 0'}} className = "wAuto"
                        buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.qtrDis}
                         onMouseOver={(e)=>this.getHoverDate("Quarter",name)}/>
                         </IconButton>
                       ))}
                    </div> : null}

                {this.state.showprd ?  <div className="ptpperiod" style={{display: 'inline-table'}}>
                  <div style={{display: 'inline','wordWrap':'break'}}>
                   {this.state.p2p4.map((name) => (
                      <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                       </IconButton>
                     ))}
                    </div>
                    <div>
                    {this.state.p2p4_1.map((name) => (
                      <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                       </IconButton>
                     ))}
                      </div>
                    <div>
                      {this.state.p2p4_2.map((name) => (
                      <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                       </IconButton>
                     ))}
                      </div>
                    <div>
                      {this.state.p2p4_3.map((name) => (
                      <IconButton tooltipStyles={{'marginTop':'5px'}} tooltip= {this.state.hoverDt} style={{'width':'auto','padding':'0 12px 0 0','height':'35px','zIndex':'10000'}}>
                      <RaisedButton  label={name.split("-")[1]} value={name} onClick={(e)=>this.year(e,{name})} style={{'margin':'0 2px 2px 0','backgroundColor': 'transparent !important'}} className="p2pAuto"
                      buttonStyle={{'height':'25px','lineHeight':'inherit'}} labelColor ={"white"} id={name} disabled={this.state.p2pDis}
                       onMouseOver={(e)=>this.getHoverDate("Period",name)}/>
                       </IconButton>
                     ))}
                      
                  </div>
                  </div>    :null}                                                        
                  
                  <br/>



                  <br/>



                 
                   
                  </div>
                  </MuiThemeProvider>
                  </ul>
                  </li>:null}

                 </ul>
                
                 <button  className={this.state.applyDisabled ? 'buttonStyle' : 'liDisabled buttonStyle'}  onClick={(e)=>this.loadDashboard()}> Apply </button>  
                  <button className="buttonStyle" onClick={(e)=>this.dispInputBox()}> Save  </button>  
                              <div id="myModal1" className="modal1">

                                <div className="modal-content1">
                                  <div className="modal-header1">
                                    <span className="close" id="popClose" onClick={(e)=>this.closeele()}>&times;</span>
                                    <p> Preferences </p>
                                  </div>
                                  <div className="modal-body1 custmodalboday1">
                                  <div className="prefdiv">
                                  <span id="prefLabel">Preference Name : </span><input type="text" id="preferVal"/>
                                  </div>
                                  <div className="prefdiv">
                                  {this.state.prefValues.map((name) => (
                                  <div  key={name} value={name}>{name} <br/><br/></div>
                                    ))}
                                    </div>
                                  <button className="buttonStylepref" onClick={(e)=>this.saveFilter()} id="savePref"> Save  </button> 
                                  </div>
                                
                                </div>

                              </div>          

                                      
</div>
</div>
</div>
)
}


componentDidMount(){
  this.loadFilters();
  this.loadTimeframe("");
  sessionStorage.vendor="123";
 $(document).click(function(e) 
{
  // e.stopPropagation();
    var container = $("#hideDiv");
    var timediv= $("#timed");
    var timediv1= $("#timed1");

    var container1 = $("#hideDiv");
    var fildiv= $("#filterApp");
    var fildiv1= $("#filterApp1");
    var popClose=$("#popClose");
    var prefBut=$(".prefButton");
    var delPref=$(".delFil");
    var editPref= $(".editFil");
    
    if (!container.is(e.target) && container.has(e.target).length === 0 && !timediv.is(e.target) &&  !timediv1.is(e.target)
     && document.getElementById("TimeFrameMenu") != null)
    {
         document.getElementById("TimeFrameMenu").style.display = 'none';
    }

    if (!container1.is(e.target) && container1.has(e.target).length === 0 && !fildiv.is(e.target) &&  !fildiv1.is(e.target)
     && document.getElementById("FilterMenu") != null && !prefBut.is(e.target) && !delPref.is(e.target) && !editPref.is(e.target)
     && !popClose.is(e.target) && !e.target.className.includes("fa-check-circle"))
    {
         document.getElementById("FilterMenu").style.display = 'none';
         document.getElementById("filcls").classList.add("clsHeader");
        document.getElementById("filcur").classList.remove("clsHeader");

    }
    if(e.target.className.includes("fa-check-circle")==true){
      document.getElementById("FilterMenu").style.display = 'block';
         document.getElementById("filcls").classList.remove("clsHeader");
        document.getElementById("filcur").classList.add("clsHeader");
    }
});
}

 componentWillReceiveProps({comprEn,comprVal,startDate,endDate,isHome,measure,showCmp,filval,filname,downFlag}) {


  this.onload1({comprEn,isHome,measure,showCmp});
  if(downFlag==true){
this.datadownload(filval,filname);
  }
  

} 

 shouldComponentUpdate(nextProps, nextState) {
if (nextProps.isRefresh != this.props.isRefresh) {
if(nextProps.isRefresh=="Y"){
//  this.setState({divVal: [],divisionVal:[],regVal:[],mrktVal:[],gradeVal:[],jobVal:[],timecVal:[],timerVal:[],timefVal:[],storenumVal:[],deptVal:[],strvolVal:[],filterVisible:false,pftVal:[],filterVisible22:false,
// 	  filterVisible1:false,filterVisible2:false,filterVisible3:false,filterVisible4:false,filterVisible5:false,filterVisible6:false,filterVisible7:false,filterVisible8:false,
// 	  filterVisible9:false,
// 	  filterVisible10:false,filterVisible11:false,filterVisible20:false,filterVisible21:false,orgVal:[],
//   checked:true,
// checked1:true,checked2:true,checked3:true,checked4:true,checked5:true,checked6:true,checked7:true,checkedA:true,
// measureVal:['Headcount','Exit','Turnover','Vacancy','Open Req', '4+ Absenteeism','9+ Absenteeism','AB PT Turnover']});
//       this.loadFilters();
// 	  this.loadDashboard1();
this.loadDashboard();
}

}

// if(nextProps.downFlag == true && this.props.downFlag !=false && this.isNullOrUndefined(nextProps.filval)  && this.isNullOrUndefined(nextProps.filname)){
//   this.props.downFlag =true;
//   this.datadownload(nextProps.filval,nextProps.filname);
// }

 if(this.isNullOrUndefined(nextProps.filterSel)  && nextProps.filterSel != this.props.filterSel ){


  //this.setState({filterSel:nextProps.filterSel["REGION_NAME"]});
  var data =nextProps.filterSel;
  filterDef = nextProps.filterSel;
   var optKey = Object.keys(data);
  var dataArr=[];
  var filDef=["Filters Selected - All"];

  for(var i=0; i<optKey.length; i++){
    var a = data[optKey[i]];
    // if(nextProps.isHome == true){
      var name="";
if(optKey[i] == "BUSINESS_UNIT"){
    name = "Business Unit";
}
if(optKey[i] == "REGION_NAME"){
    name = "Region";
}
if(optKey[i] == "MARKET_AREA_NAME"){
    name = "Market Area Name";
}
if(optKey[i] == "STORE_NBR"){
    name = "Store Number";
}
if(optKey[i] == "Store_Volume"){
    name = "Store Volume";
}
if(optKey[i] == "Grade_Level_grp"){
    name = "Grade Level";
}
if(optKey[i] == "Job_Family"){
    name = "Job Family";
}
if(optKey[i] == "PT_FT_Temp"){
    name = "PT/FT/Temp";
}
if(optKey[i] == "Time in Facility Bucket"){
    name = "Time in Facility";
}
if(optKey[i] == "Time in Role Bucket "){
    name = "Time in Role";
}
if(optKey[i] == "Time in Company Bucket"){
    name = "Time in Company";
}
if(optKey[i] == "JOB_CODE"){
    name = "Job Code";
}

name = (name != "") ? name : optKey[i];
    dataArr.push([name]+" : "+a);
    //  } else if(nextProps.isHome==false && optKey[i] == "Grade_Level_grp" && optKey[i] == "Job_Family" && optKey[i]=='PT_FT_Temp'){
    //    dataArr.push([optKey[i]]+" - "+a);
    // }
  }
  if(dataArr.length > 0){
this.setState({filterSel:dataArr});

  }else{
    this.setState({filterSel:filDef});
  }
  this.setState({filterCnt:optKey.length});
// this.setState({filterSel:optKey.length});

}
else{
	return true;

	}

}
}

export default Sidebar;
