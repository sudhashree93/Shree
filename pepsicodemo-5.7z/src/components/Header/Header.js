import React, {Component} from 'react';
import Tableau from 'tableau-api';
import ReactDOM from 'react-dom';
var urlChange;
var counter=0;
var selectedDashboard;
var vendor;
import {
  Badge,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Nav,
  NavItem,
  NavLink,
  NavbarToggler,
  NavbarBrand,
  DropdownToggle
} from 'reactstrap';
import axios from 'axios';
import ToggleDisplay from 'react-toggle-display';



class Header extends Component {

  constructor(props) {
    super(props);
	this.refresh = this.refresh.bind(this);
    this.toggle=this.toggle.bind(this);
    this.toggle1=this.toggle1.bind(this);
    this.toggle2=this.toggle2.bind(this);
    this.toggle3=this.toggle3.bind(this);
    this.toggle4=this.toggle4.bind(this);
	this.toggle5=this.toggle5.bind(this);
    this.click=this.click.bind(this);
    this.remove=this.remove.bind(this);
    this.toggleDwn=this.toggleDwn.bind(this);
    this.apply=this.apply.bind(this);
this.toggle6=this.toggle6.bind(this);
    this.state = {
	showFull:true,
  showH: false,
  showR: false,
  showM: false,
  showP: false,
  showT: false,
      dropdownOpen: false,
      dropdownOpen1: false,
      dropdownOpen2: false,
      dropdownOpen3: false,
      dropdownOpen4: false,
	  dropdownOpen5:false,
      dropdownOpenDwn:false,
      ifClicked:false,
      ifClicked1:false,
      ifClicked2:false,
      ifClicked3:false,
      ifClicked4:false,
	   dropdownOpen6:false
	 
    };
  }
  refresh(){
   
   this.props.onData1Changed(["refresh"]);
  
  }
  apply(val){
    this.props.applyFilter(val);
  }
  
  toggle6() {
  this.setState({
    dropdownOpen6: !this.state.dropdownOpen6

  });
}

  click(urlVal){ 
   $('.dropdown').slideUp();
   var cbs;
   var cbs1;
    var cbs2;
   var cbs3;
   var cbs4;
   var cbs5;   
if(urlVal=="cs"){
   cbs = "Current Summary";
   selectedDashboard="Workforce/"+cbs;
 }else if(urlVal=="cd"){
   cbs="Current Detail";
   selectedDashboard="Workforce/"+cbs;    
 }else if(urlVal=="trnd"){
   cbs="Trend";
   selectedDashboard="Workforce/"+cbs;    
 }else if(urlVal=="prd" ){
   cbs="Period to Period";
   selectedDashboard="Workforce/"+cbs;
 } if(urlVal=="csm"){
   cbs1 = "Current Summary";
   selectedDashboard="Movement/"+cbs1;
 }else if(urlVal=="trndm"){
   cbs1="Trend";
   selectedDashboard="Movement/"+cbs1;
 }else if(urlVal=="prdm" ){
   cbs1="Period to Period";
   selectedDashboard="Movement/"+cbs1;
 }else if(urlVal=="csr" ){
   cbs2="Current Summary";
   selectedDashboard="Recruiting/"+cbs2;
 }else if(urlVal=="ch" ){
   cbs3="Current Hourly";
   selectedDashboard="Performance/"+cbs3  ;
 }else if(urlVal=="cm" ){
   cbs3="Current Management";
   selectedDashboard="Performance/"+cbs3;
 }else if(urlVal=="cst" ){
   cbs4="Current Hourly";
   selectedDashboard="Talent/"+cbs4;
 }else if(urlVal=="kpi" ){
   cbs5="KPI";
   selectedDashboard="Home/"+cbs5;
 }else if(urlVal=="exe" ){
   cbs5="Executive Summary";
   selectedDashboard="Home/"+cbs5;
 }else if(urlVal=="cmp" ){
   cbs5="Comparison";
   selectedDashboard="Home/"+cbs5;
 }




if(urlVal=="cs" ||urlVal=="cd"|| urlVal=="trnd" ||urlVal=="prd"){
  document.getElementById("Home").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Headcount").style.borderBottom = "3px solid #fbb61a";         
  document.getElementById("Recruiting").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Movement").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Performance").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Talent").style.borderBottom = "3px solid #399bd5";
   document.getElementById("dropdownMenuHeadcount").style.display = "none";


  var DynamicEle = React.createClass({
    render: function(){
      return(
       <span id="staticEle"> <div className=""></div><p className="green pipeMargin"></p><li><span className="imgAlign"><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>{cbs}</li></span>
       )
    }
  })

  ReactDOM.render( <DynamicEle/>, document.getElementById('appendEle'));
      document.getElementById("staticEle").style.display = 'block';   
      if(document.getElementById("staticEle2")!==null){ document.getElementById("staticEle2").style.display = 'none'; }  
      if(document.getElementById("staticEle1")!==null){ document.getElementById("staticEle1").style.display = 'none'; }
      if(document.getElementById("staticEle3")!==null){ document.getElementById("staticEle3").style.display = 'none'; }
      if(document.getElementById("staticEle4")!==null){ document.getElementById("staticEle4").style.display = 'none'; }
      if(document.getElementById("staticEle5")!==null){ document.getElementById("staticEle5").style.display = 'none'; }    
}
if(urlVal=="csm" || urlVal=="trndm" ||urlVal=="prdm"){
  document.getElementById("Home").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Headcount").style.borderBottom = "3px solid #399bd5";         
  document.getElementById("Recruiting").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Movement").style.borderBottom = "3px solid #fbb61a";
  document.getElementById("Performance").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Talent").style.borderBottom = "3px solid #399bd5"; 
   document.getElementById("dropdownMenuMovement").style.display = "none";
  var DynamicEle1 = React.createClass({
    render: function(){
      return(
       <span id="staticEle1"> <div className=""></div><p className="green pipeMargin"></p><li><span className="imgAlign"><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>{cbs1}</li></span>
       )
    }
  })

  ReactDOM.render( <DynamicEle1/>, document.getElementById('appendEle1'));
        document.getElementById("staticEle1").style.display = 'block';   
      if(document.getElementById("staticEle2")!==null){ document.getElementById("staticEle2").style.display = 'none'; }  
      if(document.getElementById("staticEle")!==null){ document.getElementById("staticEle").style.display = 'none'; }
      if(document.getElementById("staticEle3")!==null){ document.getElementById("staticEle3").style.display = 'none'; }
      if(document.getElementById("staticEle4")!==null){ document.getElementById("staticEle4").style.display = 'none'; }
      if(document.getElementById("staticEle5")!==null){ document.getElementById("staticEle5").style.display = 'none'; } 
}

if(urlVal=="csr"){
  document.getElementById("Home").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Headcount").style.borderBottom = "3px solid #399bd5";         
  document.getElementById("Recruiting").style.borderBottom = "3px solid #fbb61a";
  document.getElementById("Movement").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Performance").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Talent").style.borderBottom = "3px solid #399bd5";
   document.getElementById("dropdownMenuRecruiting").style.display = "none";  
  var DynamicEle2 = React.createClass({
    render: function(){
      return(
       <span id="staticEle2"> <div className=""></div><p className="green pipeMargin"></p><li><span className="imgAlign"><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>{cbs2}</li></span>
       )
    }
  })

  ReactDOM.render( <DynamicEle2/>, document.getElementById('appendEle2'));
      document.getElementById("staticEle2").style.display = 'block';   
      if(document.getElementById("staticEle")!==null){ document.getElementById("staticEle").style.display = 'none'; }  
      if(document.getElementById("staticEle1")!==null){ document.getElementById("staticEle1").style.display = 'none'; }
      if(document.getElementById("staticEle3")!==null){ document.getElementById("staticEle3").style.display = 'none'; }
      if(document.getElementById("staticEle4")!==null){ document.getElementById("staticEle4").style.display = 'none'; }
      if(document.getElementById("staticEle5")!==null){ document.getElementById("staticEle5").style.display = 'none'; }    
}

if(urlVal=="ch" || urlVal=="cm"){
  document.getElementById("Home").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Headcount").style.borderBottom = "3px solid #399bd5";         
  document.getElementById("Recruiting").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Movement").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Performance").style.borderBottom = "3px solid #fbb61a";
  document.getElementById("Talent").style.borderBottom = "3px solid #399bd5";  
   document.getElementById("dropdownMenuPerformance").style.display = "none";
  var DynamicEle3 = React.createClass({
    render: function(){
      return(
       <span id="staticEle3"> <div className=""></div><p className="green pipeMargin"></p><li><span className="imgAlign"><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>{cbs3}</li></span>
       )
    }
  })

  ReactDOM.render( <DynamicEle3/>, document.getElementById('appendEle3'));
      document.getElementById("staticEle3").style.display = 'block';   
      if(document.getElementById("staticEle")!==null){ document.getElementById("staticEle").style.display = 'none'; }  
      if(document.getElementById("staticEle1")!==null){ document.getElementById("staticEle1").style.display = 'none'; }
      if(document.getElementById("staticEle2")!==null){ document.getElementById("staticEle2").style.display = 'none'; }
      if(document.getElementById("staticEle4")!==null){ document.getElementById("staticEle4").style.display = 'none'; }
      if(document.getElementById("staticEle5")!==null){ document.getElementById("staticEle5").style.display = 'none'; }     
}

if(urlVal=="cst"){ 
   document.getElementById("dropdownMenuTalent").style.display = "none";
  document.getElementById("Home").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Headcount").style.borderBottom = "3px solid #399bd5";         
  document.getElementById("Recruiting").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Movement").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Performance").style.borderBottom = "3px solid #399bd5";
  document.getElementById("Talent").style.borderBottom = "3px solid #fbb61a";  
  var DynamicEle4 = React.createClass({
    render: function(){
      return(
       <span id="staticEle4"> <div className=""></div><p className="green pipeMargin"></p><li><span className="imgAlign"><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>{cbs4}</li></span>
       )
    }
  })
  ReactDOM.render( <DynamicEle4/>, document.getElementById('appendEle4'));
      document.getElementById("staticEle4").style.display = 'block';   
      if(document.getElementById("staticEle")!==null){ document.getElementById("staticEle").style.display = 'none'; }  
      if(document.getElementById("staticEle1")!==null){ document.getElementById("staticEle1").style.display = 'none'; }
      if(document.getElementById("staticEle2")!==null){ document.getElementById("staticEle2").style.display = 'none'; }
      if(document.getElementById("staticEle3")!==null){ document.getElementById("staticEle3").style.display = 'none'; } 
      if(document.getElementById("staticEle5")!==null){ document.getElementById("staticEle5").style.display = 'none'; }   
   }

   if(urlVal=="kpi" || urlVal=="exe" || urlVal=="cmp"){
       document.getElementById("Home").style.borderBottom = "3px solid #fbb61a";
        document.getElementById("Headcount").style.borderBottom = "3px solid #399bd5";         
        document.getElementById("Recruiting").style.borderBottom = "3px solid #399bd5";
        document.getElementById("Movement").style.borderBottom = "3px solid #399bd5";
        document.getElementById("Performance").style.borderBottom = "3px solid #399bd5";
        document.getElementById("Talent").style.borderBottom = "3px solid #399bd5";
        var DynamicEle5 = React.createClass({
          render: function(){
            return(
             <span id="staticEle5"> <div className=""></div><p className="green pipeMargin"></p><li><span className="imgAlign"><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>{cbs5}</li></span>
             )
          }
        })
        ReactDOM.render( <DynamicEle5/>, document.getElementById('appendEle5'));
      document.getElementById("staticEle5").style.display = 'block';
      if(document.getElementById("staticEle")!==null){ document.getElementById("staticEle").style.display = 'none'; }  
      if(document.getElementById("staticEle1")!==null){ document.getElementById("staticEle1").style.display = 'none'; }
      if(document.getElementById("staticEle2")!==null){ document.getElementById("staticEle2").style.display = 'none'; }
      if(document.getElementById("staticEle3")!==null){ document.getElementById("staticEle3").style.display = 'none'; }  
       if(document.getElementById("staticEle4")!==null){ document.getElementById("staticEle4").style.display = 'none'; }    
   }

   


  this.props.onData2Changed({value: urlVal});
  console.log(urlVal);
}

remove(){

  var removeEle = document.getElementById("staticEle");
  if(removeEle != null){
  removeEle.remove();
  }
  var removeEle1 = document.getElementById("staticEle1");
  if(removeEle1 != null){
  removeEle1.remove();
  }
   var removeEle2 = document.getElementById("staticEle2");
  if(removeEle2 != null){
  removeEle2.remove();
  }
  
   var removeEle3 = document.getElementById("staticEle3");
  if(removeEle3 != null){
  removeEle3.remove();
  }
  
  var removeEle4 = document.getElementById("staticEle4");
  if(removeEle4 != null){
  removeEle4.remove();
  }  

  var removeEle5 = document.getElementById("staticEle5");
  if(removeEle5 != null){
  removeEle5.remove();
  } 
}

fullScreen(){
var elem = document.getElementsByClassName("fullscr");
if (document.requestFullscreen) {
  document.requestFullscreen();
} else if (document.msRequestFullscreen) {
  document.msRequestFullscreen();
} else if (document.mozRequestFullScreen) {
  document.mozRequestFullScreen();
} else if (document.webkitIsFullScreen ==false) {
this.setState({showFull:false}); 
  document.documentElement.webkitRequestFullscreen();
  this.props.onScrChanged("full");
 
}else if (document.webkitIsFullScreen ==true) {
this.setState({showFull:true}); 
  document.webkitExitFullscreen();
  this.props.onScrChanged("exit");
  
  }
}

toggle() {
  this.setState({
    dropdownOpen: !this.state.dropdownOpen,
    ifClicked : !this.state.ifClicked
  });

}

toggle1() {
  this.setState({
    dropdownOpen1: !this.state.dropdownOpen1,
    ifClicked1 : !this.state.ifClicked1
  });
}

toggle2() {
  this.setState({
    dropdownOpen2: !this.state.dropdownOpen2,
    ifClicked2 : !this.state.ifClicked2
  });
}

toggle3() {
  this.setState({
    dropdownOpen3: !this.state.dropdownOpen3,
    ifClicked3 : !this.state.ifClicked3
  });
}

toggle4() {
  this.setState({
    dropdownOpen4: !this.state.dropdownOpen4,
    ifClicked4 : !this.state.ifClicked4

  });
}

toggle5() {
  this.setState({
    dropdownOpen5: !this.state.dropdownOpen5

  });
}
toggleDwn() {
  this.setState({
    dropdownOpenDwn: !this.state.dropdownOpenDwn
  });
}

signoutbutton(){
     document.getElementById("signout").style.display = "block !important";
   document.getElementById("signout").style.zIndex = '10';

}

logout() {
    var that = this;
   axios.get('/logout1')
 .then(res => {
sessionStorage.opt="";
// window.location.href = "https://"+res.data.host + "/" + res.data.path + "/ppidp/logout?post_logout_redirect_uri=http://walmart-people-metrics.dev.walmart.com:8443/login";
// window.location.href = "https://"+res.data.host + "/" + res.data.path + "/ppidp/logout?post_logout_redirect_uri=http://localhost:3000/login";
window.location.href = "https://"+res.data.host + "/" + res.data.path + "/ppidp/logout?post_logout_redirect_uri=http://wmusdashboard.prod.walmart.com:8443/login";
  });

}


clickHome(){
document.getElementById("Home").style.borderBottom = "3px solid #fbb61a";
document.getElementById("Headcount").style.borderBottom = "3px solid #399bd5";         
document.getElementById("Recruiting").style.borderBottom = "3px solid #399bd5";
document.getElementById("Movement").style.borderBottom = "3px solid #399bd5";
document.getElementById("Performance").style.borderBottom = "3px solid #399bd5";
document.getElementById("Talent").style.borderBottom = "3px solid #399bd5";  
this.remove();

}


load(){
var modal = document.getElementById('myModal');

var btn = document.getElementById("myBtn");

var span = document.getElementsByClassName("close")[0];

    modal.style.display = "block";

span.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
}

clickMenu(tagname) {
  var x;

  if (tagname!="blank"){
      counter=counter+1;
      if (tagname=="Headcount") {
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';      
      document.getElementById("dropdownMenuAccount").style.display = 'none';
      document.getElementById("dropdownMenuInfo").style.display = 'none';
      document.getElementById("dropdownMenuHome").style.display = 'none';
         x = document.getElementById("dropdownMenuHeadcount");
      }
      else  if (tagname=="Home") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';      
      document.getElementById("dropdownMenuAccount").style.display = 'none';
      document.getElementById("dropdownMenuInfo").style.display = 'none';
         x = document.getElementById("dropdownMenuHome");
      }
      else if (tagname=="Recruiting") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';      
      document.getElementById("dropdownMenuAccount").style.display = 'none';
      document.getElementById("dropdownMenuInfo").style.display = 'none';
      document.getElementById("dropdownMenuHome").style.display = 'none';
         x = document.getElementById("dropdownMenuRecruiting");     
      }
      else if (tagname=="Movement") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';      
      document.getElementById("dropdownMenuAccount").style.display = 'none';
      document.getElementById("dropdownMenuInfo").style.display = 'none';
      document.getElementById("dropdownMenuHome").style.display = 'none';
         x = document.getElementById("dropdownMenuMovement"); 
      }
      else if (tagname=="Performance") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';      
      document.getElementById("dropdownMenuAccount").style.display = 'none';
      document.getElementById("dropdownMenuInfo").style.display = 'none';
      document.getElementById("dropdownMenuHome").style.display = 'none';
         x = document.getElementById("dropdownMenuPerformance");  
      }
      else if (tagname=="Talent") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';      
      document.getElementById("dropdownMenuAccount").style.display = 'none'; 
      document.getElementById("dropdownMenuInfo").style.display = 'none';    
      document.getElementById("dropdownMenuHome").style.display = 'none'; 
         x = document.getElementById("dropdownMenuTalent");
      }
      else if (tagname=="Download") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuAccount").style.display = 'none'; 
      document.getElementById("dropdownMenuInfo").style.display = 'none'; 
      document.getElementById("dropdownMenuHome").style.display = 'none';    
      x = document.getElementById("dropdownMenuDownload");
      }      
      else if (tagname=="Account") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';
      document.getElementById("dropdownMenuInfo").style.display = 'none';
      document.getElementById("dropdownMenuHome").style.display = 'none';
      x = document.getElementById("dropdownMenuAccount");
      }    
      else if (tagname=="Info") {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
      document.getElementById("dropdownMenuRecruiting").style.display = 'none';
      document.getElementById("dropdownMenuMovement").style.display = 'none';
      document.getElementById("dropdownMenuPerformance").style.display = 'none';
      document.getElementById("dropdownMenuTalent").style.display = 'none';
      document.getElementById("dropdownMenuDownload").style.display = 'none';
      document.getElementById("dropdownMenuAccount").style.display = 'none';
      document.getElementById("dropdownMenuHome").style.display = 'none';
      x = document.getElementById("dropdownMenuInfo");
      this.load();
      } 

    if (x.style.display == "none") 
    {     

          x.style.display = 'block';    
     }
    else
      {       
        // if(tagname == "Account" || tagname =="Info" || tagname =="Download"){
          if(tagname =="Info"){
        x.style.display = 'none';   
      }  
      }
   }else if(tagname=="blank")
   {  
      if(counter==0){
        document.getElementById("dropdownMenuHeadcount").style.display = 'none';
        document.getElementById("dropdownMenuRecruiting").style.display = 'none';
        document.getElementById("dropdownMenuMovement").style.display = 'none';
        document.getElementById("dropdownMenuPerformance").style.display = 'none';
        document.getElementById("dropdownMenuTalent").style.display = 'none'; 
        document.getElementById("dropdownMenuDownload").style.display = 'none'; 
        document.getElementById("dropdownMenuAccount").style.display = 'none'; 
        document.getElementById("dropdownMenuInfo").style.display = 'none';    
        document.getElementById("dropdownMenuHome").style.display = 'none';
      }
      else{
      counter=counter-1;
        document.getElementById("dropdownMenuHeadcount").style.display = 'none';
        document.getElementById("dropdownMenuRecruiting").style.display = 'none';
        document.getElementById("dropdownMenuMovement").style.display = 'none';
        document.getElementById("dropdownMenuPerformance").style.display = 'none';
         document.getElementById("dropdownMenuHome").style.display = 'none';
         document.getElementById("dropdownMenuTalent").style.display = 'none';
         document.getElementById("dropdownMenuDownload").style.display = 'none'; 
        document.getElementById("dropdownMenuAccount").style.display = 'none'; 
      }
    }



};


render() {
  return (
    <header id="right-side-wrapper" onMouseLeave={(e)=>this.clickMenu("blank")}>
    <p  style={{display:'none'}} id="selectedDashboardid">{selectedDashboard}</p>    
    
   <div className="menu">
        <ul className="topright">
        <li onClick={(e) =>this.clickMenu("Download")} className="ba download">
          <a ><i className="fa download fa-download topr" aria-hidden="true"></i>
              <ToggleDisplay show={this.state.show} tag="section3" >
              <ul className="dropdown" id="dropdownMenuDownload" style={{display:'none'}}>
                <li><a onClick={() =>this.apply("wrkbook")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Tableau Workbook</a></li>
                <li><a onClick={() =>this.apply("pdf")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>PDF</a></li>
                <li><a onClick={() =>this.apply("cross")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Crosstab</a></li>
                <li><a onClick={() =>this.apply("data1")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Data</a></li>
                <li><a onClick={() =>this.apply("img1")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Image</a></li>
                <li><a onClick={() =>this.apply("shr")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Share</a></li>
                <li className=""><a onClick={() =>this.apply("datadwn")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Data Download</a></li>
              </ul>
               </ToggleDisplay> 
            </a>
          </li>
          <li><a href="#"><i onClick={() =>this.refresh()} className="fa fa-repeat alignDown topr" aria-hidden="true"></i></a></li>
          <li>
            <a onClick={(e) =>this.clickMenu("Info")} ><i className="fa fa-info-circle topr" aria-hidden="true"></i>
              <ToggleDisplay show={this.state.show} tag="section3" >
              <div className="dropdown" id="dropdownMenuInfo" style={{display:'none'}}>
               <div id="myModal" className="modal">


  <div className="modal-content">
    <div className="modal-header">
      <span className="close">&times;</span>
      <p> Details </p>
    </div>
    <div className="modal-body custmodalboday">
    <table>
  <caption><strong>Headcount</strong>
</caption>
  <tr>
    <td>Base Wage</td>
    <td>Year To Date based wage in current Fiscal Year</td>
  </tr>
  <tr>
    <td>Department</td>
    <td>Snapshot of (the total number of active associates) the metrics being measured by departments job family</td>
  </tr>
  <tr>
    <td>FT/PT Ratio</td>
    <td>Full time associate headcount divided by part time associate headcount</td>
  </tr>
  <tr>
    <td>Headcount</td>
    <td>The total number of associates that are currently employed (as of the period measured)</td>
  </tr>
  <tr>
    
    <td>Joining Bonus</td>
    <td>Year To Date joining bonus in current Fiscal Year</td>
  </tr>
  <tr>
    
    <td>Opens</td>
    <td>The total number of job positions posted with the intent to fill</td>
  </tr>
  <tr>
    
    <td>Sub Department</td>
    <td>Snapshot of (the total number of active associates) the metrics being measured by sub-departments job family</td>
  </tr>
  <tr>
    
    <td>Vacancies</td>
    <td>The difference between structure headcount guidance and actual headcount (as of the end of the time period measured)</td>
  </tr>
   
</table>
	 

	 

     
	 
	<table>
  <caption><strong>Tenure</strong>
</caption>
  <tr>
    <td>Time in Company</td>
    <td>Number of years associates have been in the company</td>
  </tr>
  <tr>
    <td>Time in Facility</td>
    <td>Number of years associates have been in their current facility/market</td>
  </tr>
  <tr>
    <td>Time in Role</td>
    <td>Number of years associates have been in their current role regardless of facility</td>
  </tr>
  
   
</table>
	 
	<table>
  <caption><strong>Movement</strong>
</caption>
 <tr>
    <td>Annualized Turnover</td>
    <td>The total number of exits in the past 26 Pay Periods (12 months) divided by the number of associates as of the end of the pay period measured</td>
  </tr>
  <tr>
    <td>Demotions</td>
    <td>Associate moving to a lower pay band</td>
  </tr>
  <tr>
    <td>Exits</td>
    <td>The total number of associates exited from the company, excluding Temp associates</td>
  </tr>
  <tr>
    <td>Laterals</td>
    <td>Associate moving to a similar pay band</td>
  </tr>
  <tr>
    <td>Movement</td>
    <td>Each transfer of an associate that is either promotion, lateral, or demotion based on pre and post pay grade levels</td>
  </tr>
  <tr>
    <td>Promotions</td>
    <td>Associate moving to a higher pay band</td>
  </tr>
  <tr>
    <td>Terminations</td>
    <td>The total number of associates exited from the company, excluding Temp associates</td>
  </tr>
  
   
	

	
	
	
	

</table>
	 
	<table>
  <caption><strong>Time Frames</strong>
</caption>
  <tr>
    <td>Annualized</td>
    <td>Accumulated measure within the past 26 Pay Periods (rolling 12 months)</td>
  </tr>
  <tr>
    <td>Average</td>
   
  </tr>
  <tr>
    <td>Current Period</td>
    <td>Accumulated measure within the current pay period</td>
  </tr>
  <tr>
    <td>Period to Period Comparison</td>
    <td>Metric comparison of the current month to the same month in the previous year</td>
  </tr><tr>
    <td>Trend</td>
    <td>Metric comparison of a given period of time to a previous period of time: PoP</td>
  </tr>
  <tr>
    <td>YTD - Year to Date</td>
    <td>Accumulated measure from the beginning of the Fiscal Year to the end of previous pay period end</td>
  </tr>
  <tr>
    <td>YoY - Year over Year</td>
    <td>Metric comparison of the current month to the same month in the previous year</td>
  </tr>
  
   	
	
	






</table>
	 
	<table>
  <caption><strong>Acronyms</strong>
</caption>
  <tr>
    <td>FT</td>
    <td>Full-Time</td>
  </tr>
  <tr>
    <td>PT</td>
    <td>Part-Time</td>
  </tr>
  <tr>
    <td>Temp</td>
    <td>Temporary</td>
  </tr> 
  <tr>
    <td>Mgmt	</td>
    <td>Management</td>
  </tr>
  <tr>
    <td>Hrly	</td>
    <td>Hourly</td>
  </tr>
  <tr>
    <td>Exit	</td>
    <td>Terminations</td>
  </tr>
  <tr>
    <td>HC	</td>
    <td>Headcount</td>
  </tr> 
  <tr>
    <td>TY		</td>
    <td>This (Fisical) Year</td>
  </tr>
  <tr>
    <td>LY			</td>
    <td>Last (Fisical) Year</td>
  </tr><tr>
    <td>YTD			</td>
    <td>(Fisical) Year to Date</td>
  </tr><tr>
    <td>EOY			</td>
    <td>End-of-(Fisical) Year</td>
  </tr><tr>
    <td>Ann.			</td>
    <td>Annualized</td>
  </tr><tr>
    <td>TIF			</td>
    <td>Time-in-Facility</td>
  </tr><tr>
    <td>TIR			</td>
    <td>Time-in-Role</td>
  </tr>
  <tr>
    <td>TIC		</td>
    <td>Time-in-Company</td>
  </tr>
  <tr>
    <td>CM		</td>
    <td>Club Manager</td>
  </tr>
  
   
</table>
    </div>
   
  </div>

</div>
	 
              </div>
               </ToggleDisplay> 
            </a>
          </li>       
          
          <li className="accountoption" >          
            <a className="topr topacc" onMouseEnter={(e) =>this.clickMenu("Account")}>User<i className="fa fa-angle-down topr" aria-hidden="true"></i>
                <ul className="dropdown" id="dropdownMenuAccount" style={{display:'none'}}>
                  <li><a onClick={(e) =>this.logout(e)}>Sign out</a></li>
                </ul>
              </a>
           </li> 

           <li><a onClick={(e)=>this.fullScreen()}><i className="fa fa-arrows-alt  fullscr topr" aria-hidden="true"></i></a></li>      
        </ul>
       

  <ul className="menu-dropdown">
 

    <li className="liDisabled" onMouseOver={(e)=>this.clickMenu("Home")}>
  <a id="Home"  >
     <i   className="fa fa-home" aria-hidden="true"></i>
     <span>Home</span>&nbsp;
      <i className="fa fa-angle-down" aria-hidden="true"></i>
      <ul className="dropdown" id="dropdownMenuHome" style={{display:'none'}}>
        <li><a onClick={() =>this.click("kpi")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>KPI</a></li>
        <li><a onClick={() =>this.click("exe")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Executive Summary</a></li>
      </ul>
     </a>
    <span id="appendEle5"></span>
    </li>

    <li onMouseOver={(e) =>this.clickMenu("Headcount")}>
     <a  id="Headcount" >
      <i className="fa fa-users" aria-hidden="true"></i>  
      <span >Workforce</span>&nbsp;
      <i className="fa fa-angle-down" aria-hidden="true"></i>
      <ToggleDisplay show={this.state.show} tag="section" >
      <ul className="dropdown" id="dropdownMenuHeadcount"  style={{display:'none'}}>
      <li><a onClick={() =>this.click("cs")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Summary</a></li>
      <li><a onClick={() =>this.click("cd")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Detail</a></li>
      <li><a onClick={() =>this.click("trnd")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Trend</a></li>
      <li><a onClick={() =>this.click("prd")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Period-to-Period</a></li>
      </ul>
      </ToggleDisplay> 
     </a>
      <span id="appendEle"></span>
    </li>


    <li className="liDisabled"  onMouseOver={(e) =>this.clickMenu("Recruiting")}>
     <a id="Recruiting">
      <i className="fa fa-search" aria-hidden="true"></i>        
      <span>Recruiting</span>&nbsp;
      <i className="fa fa-angle-down" aria-hidden="true"></i>
      <ToggleDisplay show={this.state.show} tag="section1" >
      <ul className="dropdown" id="dropdownMenuRecruiting" style={{display:'none'}}>
        <li><a onClick={() =>this.click("csr")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Summary</a></li>
      </ul>
      </ToggleDisplay> 
    </a>
    <span id="appendEle2"></span>
    </li>

    <li className="liDisabled" onMouseOver={(e) =>this.clickMenu("Movement")}>
     <a id="Movement" >
      <i className="fa fa-code-fork" aria-hidden="true"></i>  
      <span>Movement</span>&nbsp;
      <i className="fa fa-angle-down" aria-hidden="true"></i>
      <ToggleDisplay show={this.state.show} tag="section2" >
      <ul className="dropdown" id="dropdownMenuMovement" style={{display:'none'}}>
        <li><a onClick={() =>this.click("csm")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Summary</a></li>
        <li><a onClick={() =>this.click("trndm")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Trend</a></li>
        <li><a onClick={() =>this.click("prdm")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Period-to-Period</a></li>
      </ul>
       </ToggleDisplay> 
     </a>
     <span id="appendEle1"></span>
    </li>

    <li className="liDisabled" onMouseOver={() =>this.clickMenu("Performance")}>
     <a id="Performance" >
      <i className="fa fa-lightbulb-o" aria-hidden="true"></i>  
      <span>Performance</span>&nbsp;
      <i className="fa fa-angle-down" aria-hidden="true"></i>
      <ul className="dropdown" id="dropdownMenuPerformance" style={{display:'none'}}>
        <li><a onClick={() =>this.click("ch")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Hourly</a></li>
        <li><a onClick={() =>this.click("cm")}><span ><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Management</a></li>
      </ul>
     </a>
     <span id="appendEle3"></span>
    </li>




    <li className="liDisabled" onMouseOver={() =>this.clickMenu("Talent")}>
    <a id="Talent" >
      <i className="fa fa-thumbs-o-up" aria-hidden="true"></i>  
      <span>Talent</span>&nbsp;
      <i className="fa fa-angle-down" aria-hidden="true"></i>
      <ul className="dropdown" id="dropdownMenuTalent" style={{display:'none'}}>
        <li><a onClick={() =>this.click("cst")}><span><i className="iconImgSmall fa fa-circle" aria-hidden="true"></i></span>Current Hourly</a></li>
      </ul>
     </a>
     <span id="appendEle4"></span>
    </li>


  </ul>

</div>
    </header>
    )
}
componentDidMount(){
   $(document).click(function(e) 
{

   if((e.target.innerHTML!="Home")&&(e.target.innerHTML!="Workforce")&&(e.target.innerHTML!="Recruiting")&&(e.target.innerHTML!="Movement")&&(e.target.innerHTML!="Performance")&&(e.target.innerHTML!="Talent")&&(e.target.classList[1]!='fa-angle-down')&&(e.target.classList[1]!='download')&&(e.target.classList[1]!='fa-info-circle') && (e.target.classList[1]!='topacc'))
   {
      document.getElementById("dropdownMenuHeadcount").style.display = 'none';
       document.getElementById("dropdownMenuRecruiting").style.display = 'none';
       document.getElementById("dropdownMenuMovement").style.display = 'none';
       document.getElementById("dropdownMenuPerformance").style.display = 'none';
       document.getElementById("dropdownMenuTalent").style.display = 'none'; 
       document.getElementById("dropdownMenuDownload").style.display = 'none'; 
       document.getElementById("dropdownMenuAccount").style.display = 'none'; 
       document.getElementById("dropdownMenuInfo").style.display = 'none';    
       document.getElementById("dropdownMenuHome").style.display = 'none';
   }

});

    if(sessionStorage.opt !=""){
    this.click(sessionStorage.opt);
    }
     if(sessionStorage.opt =="undefined" ||sessionStorage.opt =="" ){
    this.click("cs");     
    }
   var that = this;
   axios.get('/getName')
   .then(res => {
    const posts = res.data.abc;
 vendor=res.data.cde;
 sessionStorage.vendor=vendor;
  // var name = posts.split(" ");
    console.log(res);
    that.setState({uName:name[0]});
    });  
}
}

export default Header;
