import React, {Component} from 'react';
import axios from 'axios';

class Footer extends Component {
	constructor() {
        super();

        var today = new Date(),
            date = (today.getMonth() + 1) + '/' + today.getDate() + '/' + today.getFullYear();

        this.state = {
            date: date
        };
    }
  render() {
    return (
      <footer className="app-footer-1">      
       
        <span className="float-right rightFloat">Powered by LatentView</span>
      </footer>
    )
  }
}

export default Footer;
