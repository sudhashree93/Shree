var express = require('express');
var fs = require('fs');
var Router       = require('router');
/* var Response = require('express-response');
var Request = require('express-request'); */
var router=Router();

var ssoConfig = {
  "host": "idp.prod.sso.platform.prod.walmart.com",
  "port": 443,
  "path": "platform-sso-server",
  "id": "ac08cc63-00c1-4c8b-8a5a-3bbebff72765",
  "clientSecret": "APcOtYFoBHAIHDs9380TBnerglo-4N7kjWcYCxknYhxeOkDY9Vr5pQwxzci0I_XAPynFPSJ3cS5FNgyBryBA7rQ",
  "registrationToken": "AOwTmA0NEJt1qH0YTCG9xyioEkG0e5-nNLcX7iSev7gTnsImUzuqrJyzwenGnjgca_3SHNSYY4b9M4fR_Vrnrmw",
  "idTokenSigningKey": `{\"kty\":\"RSA\",\"e\":\"AQAB\",\"use\":\"sig\",\"kid\":\"97357ae4-e50e-46f9-8354-79192e2d7614\",\"alg\":\"RSA1_5\",\"n\":\"goBkVF5VMuWcAp2Ia1ssJ15bBKwCFyVPNlnivzjgS4pvFhSxOuX5LA3IpG4eOdml2SEa3IZAEu0L6aYu3wWvgI0AavrVdVZIqfuouabaBuImbQU9xh8jCBxCfnJqzHDULc2eg-371ObT5wRA0KGCb-SkQT3HrKeOijKuQf2iVMc\"}`,
  "accessTokenSigningKey": `{\"kty\":\"RSA\",\"e\":\"AQAB\",\"use\":\"sig\",\"kid\":\"7e7d6dc2-3c3a-4391-b23e-a4b6cfa0e260\",\"alg\":\"RSA1_5\",\"n\":\"sikWSHEIDmGDOICBZ8lrxrxoIIqkJ0oOJUEvMQq15ujvPl4MPIZ6rVzzhyiyVNN0AhVw1BW2-UkfKObjfKXx7F8X6JCci0uImrw7ZdtCQZUPk0EcurSVQ23tzFuZv4Y_AuMhzzI2KRhB0z2slgi0CyTk_KXS_6-JLo-tfda7NE8\"}`
};


router.get('/', (Request,Response) => {
var req=Request;
var res=Response;
  console.log("##### I am on logout route #####");
  res.clearCookie("id_token");
 res.send({"host": ssoConfig.host,"path": ssoConfig.path});
 
});


module.exports= router;
