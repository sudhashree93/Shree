var express = require('express');
var fs = require('fs');
var Router  = require('router');
var jwt = require('jsonwebtoken');
/* var Response = require('express-response');
var Request = require('express-request'); */
var walCert=fs.readFileSync('./WalmartRootCA.cer');
var gloCert=fs.readFileSync('./GlobalSign.cer');
var router=Router();
var request = require('request');

var ssoConfig = {
  "host": "idp.prod.sso.platform.prod.walmart.com",
  "port": 443,
  "path": "platform-sso-server",
  "id": "ac08cc63-00c1-4c8b-8a5a-3bbebff72765",
  "clientSecret": "APcOtYFoBHAIHDs9380TBnerglo-4N7kjWcYCxknYhxeOkDY9Vr5pQwxzci0I_XAPynFPSJ3cS5FNgyBryBA7rQ",
  "registrationToken": "AOwTmA0NEJt1qH0YTCG9xyioEkG0e5-nNLcX7iSev7gTnsImUzuqrJyzwenGnjgca_3SHNSYY4b9M4fR_Vrnrmw",
  "idTokenSigningKey": `{\"kty\":\"RSA\",\"e\":\"AQAB\",\"use\":\"sig\",\"kid\":\"97357ae4-e50e-46f9-8354-79192e2d7614\",\"alg\":\"RSA1_5\",\"n\":\"goBkVF5VMuWcAp2Ia1ssJ15bBKwCFyVPNlnivzjgS4pvFhSxOuX5LA3IpG4eOdml2SEa3IZAEu0L6aYu3wWvgI0AavrVdVZIqfuouabaBuImbQU9xh8jCBxCfnJqzHDULc2eg-371ObT5wRA0KGCb-SkQT3HrKeOijKuQf2iVMc\"}`,
  "accessTokenSigningKey": `{\"kty\":\"RSA\",\"e\":\"AQAB\",\"use\":\"sig\",\"kid\":\"7e7d6dc2-3c3a-4391-b23e-a4b6cfa0e260\",\"alg\":\"RSA1_5\",\"n\":\"sikWSHEIDmGDOICBZ8lrxrxoIIqkJ0oOJUEvMQq15ujvPl4MPIZ6rVzzhyiyVNN0AhVw1BW2-UkfKObjfKXx7F8X6JCci0uImrw7ZdtCQZUPk0EcurSVQ23tzFuZv4Y_AuMhzzI2KRhB0z2slgi0CyTk_KXS_6-JLo-tfda7NE8\"}`
};

router.get('/', (Request,Response) => {
var req=Request;
var res=Response;
  console.log("I am inside sso route");
  const d = new Date();
  const state = d.valueOf(); // get a random string
  const nonce = "ynARP8mzbC4R";
  const protocol = "http";
  const host = "wmusdashboard.prod.walmart.com:8443";

  if (req.query.code) {

    const base64auth = new Buffer(`${ssoConfig.id}:${ssoConfig.clientSecret}`).toString("base64");
    const data = {
      "grant_type": "authorization_code", 
      "code": req.query.code,
      "redirect_uri": "http://wmusdashboard.prod.walmart.com:8443/login"
    };

    const options = {
      method: "POST",
      url: `https://${ssoConfig.host}/${ssoConfig.path}/token`,
      json: true,
      headers: {
	  "Content-Type": "application/json",
        "Authorization": `Basic ${base64auth}`
      },
      rejectUnauthorized: false,
      ca: [fs.readFileSync('./WalmartRootCA.cer'),fs.readFileSync('./GlobalSign.cer')],
      body: data
    };
	
	//console.log(options);

    request(options, function (error, response, body) {
      res.cookie('id_token', body.id_token, {
        maxAge: body.expires_in * 1000
      });
	  console.log(body.id_token);
	  const decodedToken = jwt.decode(body.id_token);
	  console.log(decodedToken.name);
      res.redirect(302, 'http://wmusdashboard.prod.walmart.com:8443');
	  
    });
  } else {
    res.redirect(`https://${ssoConfig.host}/${ssoConfig.path}/authorize?response_type=code&scope=openid&client_id=${ssoConfig.id}&state=${state}&redirect_uri=${protocol}%3A%2F%2F${host}%2Flogin&nonce=${nonce}`);
  }
});


module.exports = router;
