"use strict"
var express = require('express');
var app = express();
var path = require('path');
var jsonfile = require('jsonfile')
var fs = require('fs');
var ssoLoginRoutes = require('./route/login.js');
var ssoLogoutRoutes = require('./route/logout.js');
var Router       = require('router');
var cookieParser=require('cookie-parser');
var decodedToken;
var router=Router();
var jwt = require('jsonwebtoken');
// var downData=[];
const csv=require('csvtojson');
let csvToJson = require('convert-csv-to-json');

  //app.use('/home', express.static('build'));

app.use(express.static('build'));

app.use(cookieParser());



 app.get('/',function(req,res, next){
   res.sendFile(path.resolve(__dirname,'build','index.html'));

 console.log("removed");
  //     if (!req.cookies.id_token) {
 	// console.log("yes");
  //   res.redirect("/login");
  //  } else {
  // console.log("no");
 	// res.redirect("/home");
	
  //  }      
}); 

 app.get('/logout1',function(req,res, next){
	res.redirect("/logout");
}); 




function addRoutes(attach,  Router){
console.log('login');
var attac=attach;
var router=Router;
  app.use(attach, router);
}

addRoutes('/login', ssoLoginRoutes);
addRoutes('/logout', ssoLogoutRoutes);


var uName;
var userID;
function authChecker(req,res,next) {
console.log("called");
  var jwt = require('jsonwebtoken');
  decodedToken = jwt.decode(req.cookies.id_token);
  if(decodedToken != undefined && decodedToken !="" && decodedToken !=null){
console.log("abc",decodedToken);
 uName= decodedToken.name;
 userID=decodedToken.loginId.split("\\");
 userID=userID[1];
 console.log("name",uName);
 console.log("user",userID);
}
  if (!req.cookies.id_token) {
  
    return res.redirect('/login');
	 
  }
next();
}



 
// let fileInputName = './data/Datadownload.csv';
// let fileOutputName = './data/Datadownload.json';
 
// csvToJson.generateJsonFileFromCsv(fileInputName,fileOutputName);

// const csvFilePath='./data/Datadownload.csv';
// csv()
// .fromFile(csvFilePath)
// .on('json',(jsonObj)=>{
//    // var abc = jsonObj;
//             console.log(jsonObj);
           
//             downData.push(jsonObj);
           

// })
// .on('done',(error)=>{
//     console.log('end');
//      var file = './data/downloadData.json';
//   for(var i=0; i<downData.length;i++){
//     jsonfile.writeFileSync(file, downData[i],{spaces: 2},{flag: 'a'})
//     }
// })

var downData=fs.readFileSync('./data/Datadownload.json', 'utf8');
downData  =JSON.parse(downData); 

var userData=fs.readFileSync('./data/userData.json', 'utf8');
userData  =JSON.parse(userData); 

var segData=fs.readFileSync('./data/segData.json', 'utf8');
segData  =JSON.parse(segData); 

var deptData=fs.readFileSync('./data/deptData.json', 'utf8');
deptData  =JSON.parse(deptData); 

var timeData=fs.readFileSync('./data/timeData.json', 'utf8');
timeData  =JSON.parse(timeData); 

var timeFrame=fs.readFileSync('./data/timeFrame.json', 'utf8');
timeFrame  =JSON.parse(timeFrame); 

var jobData=fs.readFileSync('./data/jobfamilyData.json', 'utf8');
jobData  =JSON.parse(jobData); 

var gradeData=fs.readFileSync('./data/gradeData.json', 'utf8');
gradeData  =JSON.parse(gradeData); 

var pftData=fs.readFileSync('./data/pftData.json', 'utf8');
pftData  =JSON.parse(pftData); 

var measureData=fs.readFileSync('./data/measureData.json', 'utf8');
measureData  =JSON.parse(measureData); 



function userfilters(){
var filters={};
    if(userID != undefined && userID !=""){

        filters["id"] = [userID];
    
console.log("filters",filters);
 var result = userData.filter(function (o) {
        return Object.keys(filters).every(function (k) {
            return filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });
    console.log("result",result);
var datafilters={};
var values=[];
    for(var i=0; i < result.length; i++){

        values.push(result[i]["Value"]);
 
    }
    console.log(values)
    for(var i=0; i < result.length; i++){
       if(result[i]["Role"]=="Market"){

        datafilters["MARKET_AREA_NAME"]=values;
    }

    if(result[i]["Role"]=="Division"){

            datafilters["Division"]=values;
    }
    if(result[i]["Role"]=="Region"){

        datafilters["REGION_NAME"]=values;
    }
    if(result[i]["Role"]=="Store Nbr"){

        datafilters["STORE_NBR"]=values;
    }
    }
    console.log(datafilters)
    return datafilters;
    }else{

        return {};
    }
}

function getdefFilters(val,data){

    var result = data.filter(function (o) {
        return Object.keys(val).every(function (k) {
            return val[k].some(function (f) {
                return o[k] === f;
            });
        });
        });
        return result;
}

app.get('/getDefaultFilter',function(req,res){
var currentSearchResult = req.query.value;
var name = req.query.prefName;
var dataFilter=[];
var data=fs.readFileSync('./data/selFilter.json', 'utf8');
var json  =JSON.parse(data); 
 for(var i=0;i<json.length;i++){
        if(json[i]["vendor"]==currentSearchResult && json[i]["name"]==name ){
             dataFilter.push(json[i]);
             console.log(dataFilter[0]);
        }
    }
var filters={};
var filtersPpl={};
var filtersDept={};
var deptFilters=deptData;
var gradeFilters = gradeData;
     if(dataFilter[0]["BUSINESS_UNIT"]){
        var bunit = {};
        bunit["BUSINESS_UNIT"] = dataFilter[0]["BUSINESS_UNIT"];
        var result=getdefFilters(bunit,segData);
        if(result.length>0){
        filters["BUSINESS_UNIT"] = dataFilter[0]["BUSINESS_UNIT"];
        }else{
            delete dataFilter[0]["BUSINESS_UNIT"];
        }
    }

    if(dataFilter[0]["Division"]){
        var div = {};
        div["Division"] = dataFilter[0]["Division"];
         var result=getdefFilters(div,segData);
        if(result.length>0){
        filters["Division"] = dataFilter[0]["Division"];
        }else{
            delete dataFilter[0]["Division"];
        }
    }

    if(dataFilter[0]["REGION_NAME"]){
         var reg = {};
        reg["REGION_NAME"] = dataFilter[0]["REGION_NAME"];
         var result=getdefFilters(reg,segData);
        if(result.length>0){
        filters["REGION_NAME"] = dataFilter[0]["REGION_NAME"];
        }else{
            delete dataFilter[0]["REGION_NAME"];
        }
    }


    if(dataFilter[0]["MARKET_AREA_NAME"]){

        dataFilter[0]["MARKET_AREA_NAME"]= dataFilter[0]["MARKET_AREA_NAME"].map(Number);
        var mrkt = {};
        mrkt["MARKET_AREA_NAME"] = dataFilter[0]["MARKET_AREA_NAME"];
        var result=getdefFilters(mrkt,segData);
        if(result.length>0){
        filters["MARKET_AREA_NAME"] = dataFilter[0]["MARKET_AREA_NAME"];
        }else{
            delete dataFilter[0]["MARKET_AREA_NAME"];
        }
    }


    if(dataFilter[0]["STORE_NBR"]){
         dataFilter[0]["STORE_NBR"]= dataFilter[0]["STORE_NBR"].map(Number);
        var strnbr = {};
        strnbr["STORE_NBR"] = dataFilter[0]["STORE_NBR"];
        var result=getdefFilters(strnbr,segData);
        if(result.length>0){
        filters["STORE_NBR"] = dataFilter[0]["STORE_NBR"];
        }else{
            delete dataFilter[0]["STORE_NBR"];
        }
      }


    if(dataFilter[0]["Store_Volume"]){
       var strvol = {};
        strvol["Store_Volume"] = dataFilter[0]["Store_Volume"];
        var result=getdefFilters(strvol,segData);
        if(result.length>0){
        filters["Store_Volume"] = dataFilter[0]["Store_Volume"];
        }else{
            delete dataFilter[0]["Store_Volume"];
        }
    }

    if(dataFilter[0]["Department"]){
     
       var dept = {};
        dept["DEPARTMENT"] = dataFilter[0]["Department"];
        var result=getdefFilters(dept,deptData);
        if(result.length>0){
        filtersDept["DEPARTMENT"] = dataFilter[0]["Department"];
        deptFilters = result;
        }else{
            delete dataFilter[0]["Department"];
            
        }
    }

    if(dataFilter[0]["Job_Family"]){
       var job = {};
        job["Job_Family"] = dataFilter[0]["Job_Family"];
        var result=getdefFilters(job,jobData);
        if(result.length>0){
        filtersPpl["Job_Family"] = dataFilter[0]["Job_Family"];
        }else{
            delete dataFilter[0]["Job_Family"];
        }
    }

    if(dataFilter[0]["Grade_Level_grp"]){
       var dept = {};
        dept["GRADE_LEVEL_GRP"] = dataFilter[0]["Grade_Level_grp"];
        var result=getdefFilters(dept,gradeData);
        if(result.length>0){
        gradeFilters = result;
        }else{
            delete dataFilter[0]["Grade_Level_grp"];
        }
    }

     if(dataFilter[0]["JOB_CODE"]){
       var dept = {};
        dept["JOB_CODE"] = dataFilter[0]["JOB_CODE"];
        var result=getdefFilters(dept,jobData);
        if(result.length>0){
            filtersPpl["JOB_CODE"] = dataFilter[0]["JOB_CODE"];
        }else{
            delete dataFilter[0]["JOB_CODE"];
        }
    }

 var segFilters=getdefFilters(filters,segData);
 var pplFilters=getdefFilters(filtersPpl,jobData);
 var datafilters = userfilters();
 segFilters=getdefFilters(datafilters,segFilters);
    var bUnit=[];
    var division=[];
    var region =[];
    var market =[];
    var store =[];
     var storeV=[];
     var dept=[];
     var job=[];
     var grade=[];
     var jobc=[];



for(var i=0; i < segFilters.length; i++){

    bUnit.push(segFilters[i]["BUSINESS_UNIT"]);
    division.push(segFilters[i]["Division"]);
    region.push(segFilters[i]["REGION_NAME"]);
    market.push(segFilters[i]["MARKET_AREA_NAME"]);
    storeV.push(segFilters[i]["Store_Volume"]);
    store.push(segFilters[i]["STORE_NBR"]);


}
console.log(deptFilters);
for(var i = 0; i < deptFilters.length; i++) {
    dept.push(deptFilters[i].DEPARTMENT);
}

for(var i = 0; i < gradeFilters.length; i++) {
    grade.push(gradeFilters[i].GRADE_LEVEL_GRP);
}

for(var j = 0; j < pplFilters.length; j++) {
    job.push(pplFilters[j].Job_Family);
    jobc.push(pplFilters[j].JOB_CODE);
}

    grade = grade.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
    job = job.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
    jobc = jobc.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
 

dept = dept.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})

bUnit = bUnit.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
division = division.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
region = region.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
market = market.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
store = store.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
storeV = storeV.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})

bUnit.sort();
division.sort();
region.sort();
market.sort(function(a, b){return a - b});
store.sort(function(a, b){return a - b});
storeV.sort();
dept.sort();
job.sort();
jobc.sort();
grade.sort();

res.send({dataFilter,bUnit,division,region,market,store,storeV,dept,job,grade,jobc});
});

app.get('/saveFilter',function(req,res){

var currentSearchResult = JSON.parse(req.query.value);
var addData=req.query.addData;
var name = req.query.prefName;
var editName= req.query.editName;
var data=[];

fs.readFile('./data/selFilter.json', function (err, data) {
    if (err) {
        return console.log(err);
    }
    var json = JSON.parse(data);
   
    console.log(currentSearchResult["vendor"]);
    if(addData=="replace"){

    if(editName !="" && editName != undefined){
        currentSearchResult["name"]=editName;
    }
    for(var i=0;i<json.length;i++){
        if(json[i]["name"]==name && json[i]["vendor"]==currentSearchResult["vendor"]){
            json.splice(i,1);
            console.log("yes");
        }
    }
    }
    // if(addData=="new"){
    // for(var i=0;i<json.length;i++){
    //     if(json[i]["name"]==name && json[i]["vendor"]==currentSearchResult["vendor"]){
    //        currentSearchResult["name"]=name+1;
    //     }
    // }
    // }
    
    json.push(currentSearchResult);

    fs.writeFile("./data/selFilter.json", JSON.stringify(json));
    res.send({});
})

});

app.get('/deleteFilter',function(req,res){

var vendor=req.query.value;
var name = req.query.prefName;
var data=[];

fs.readFile('./data/selFilter.json', function (err, data) {
    if (err) {
        return console.log(err);
    }
    var json = JSON.parse(data);
   
   
    for(var i=0;i<json.length;i++){
        if(json[i]["name"]==name && json[i]["vendor"]==vendor){
            json.splice(i,1);
            console.log("yes");
            // data.push(json[i]);
        }
    }
    
    
    // json.push(currentSearchResult);

    fs.writeFile("./data/selFilter.json", JSON.stringify(json));
    res.send({});
})

});

app.get('/chkFilter',function(req,res){

var vendor = req.query.vendorID;
var filterValues=[];

fs.readFile('./data/selFilter.json', function (err, data) {
    if (err) {
        return console.log(err);
    }
    var json = JSON.parse(data);
   
    // console.log(currentSearchResult["vendor"]);
    for(var i=0;i<json.length;i++){
        if(json[i]["vendor"]==vendor){
           
           filterValues.push(json[i]);
           
        }
    }
    var count= filterValues.length;
    filterValues.sort(function (a, b) {
    return a.name.localeCompare(b.name);
    });
    
    res.send({filterValues,count});
})

});


app.get('/getSegmentData',function(req,res){
console.log("in");
var bUnit = [];
var division=[];
var region =[];
var market =[];
var store =[];
var storevol=[];



   var datafilters = userfilters();
    
 var segdataset = segData.filter(function (o) {
        return Object.keys(datafilters).every(function (k) {
            return datafilters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });
for(var i = 0; i < segdataset.length; i++) {
    bUnit.push(segdataset[i].BUSINESS_UNIT);
    division.push(segdataset[i].Division);
    region.push(segdataset[i].REGION_NAME);
    market.push(segdataset[i].MARKET_AREA_NAME);
    store.push(segdataset[i].STORE_NBR);
    storevol.push(segdataset[i].Store_Volume);
}
 bUnit = bUnit.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
 division = division.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
 region = region.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
 market = market.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
 store = store.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
  storevol = storevol.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
            bUnit.sort();
            division.sort();
            region.sort();
            market.sort(function(a, b){return a - b});
            store.sort(function(a, b){return a - b});
            storevol.sort();
 res.send({bUnit,division,region,market,store,storevol});
});

app.get('/getDeptData',function(req,res){

var dept = [];

for(var i = 0; i < deptData.length; i++) {
    dept.push(deptData[i].DEPARTMENT);
}
 dept = dept.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
 dept.sort();
 res.send({dept});
});

app.get('/getPftMeasure',function(req,res){
var pft = [];
var measure=[];
for(var i = 0; i < pftData.length; i++) {
    pft.push(pftData[i].PFT);
}
for(var i = 0; i < measureData.length; i++) {
    measure.push(measureData[i].measure);
}
pft.sort();
 measure.sort();
 res.send({pft,measure});
});

app.get('/getPeopleData',function(req,res){

var timec = [];
var job=[];
var jobc=[];
var grade=[];
for(var i = 0; i < timeData.length; i++) {
    timec.push(timeData[i].TIME);
}

for(var i = 0; i < gradeData.length; i++) {
    grade.push(gradeData[i].GRADE_LEVEL_GRP);
}

for(var j = 0; j < jobData.length; j++) {
    job.push(jobData[j].Job_Family);
    jobc.push(jobData[j].JOB_CODE);
}

 jobc = jobc.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
    job = job.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
 job.sort();
 jobc.sort();
 grade.sort();
 res.send({job,jobc,grade,timec});
});

app.get('/changeVal',function(req,res){

 
	var bUnit1 = req.query.bUnit;
    var division1=req.query.division;
    var region1 =req.query.region;
    var market1 =req.query.market;
    var store1 =req.query.store;
    var filter = req.query.filter;
    var storeV1 = req.query.storeV;
    var bUnit=[];
    var division=[];
    var region =[];
    var market =[];
    var store =[];
     var storeV=[];
     var filters={};


    if(bUnit1 != undefined && bUnit1 !=""){

        filters["BUSINESS_UNIT"] = bUnit1;
    }

    if(division1 != undefined && division1!=""){

         filters["Division"] = division1;
    }

    if(region1 != undefined && region1 !=""){

        filters["REGION_NAME"] = region1;
		
    }


    if(market1 != undefined  && market1 !=""){

        market1= market1.map(Number);
        filters["MARKET_AREA_NAME"] = market1;
    }


    if(storeV1 != undefined  && storeV1 !=""){

        filters["Store_Volume"] = storeV1;
      }


    if(store1 != undefined && store1 !=""){
        store1= store1.map(Number);
        filters["STORE_NBR"] = store1;
    }
console.log("Filters are  " ,filters);

 var result = segData.filter(function (o) {
        return Object.keys(filters).every(function (k) {
            return filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

 var datafilters = userfilters();
    
  result = result.filter(function (o) {
        return Object.keys(datafilters).every(function (k) {
            return datafilters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

for(var i=0; i < result.length; i++){

    bUnit.push(result[i]["BUSINESS_UNIT"]);
    division.push(result[i]["Division"]);
    region.push(result[i]["REGION_NAME"]);
    market.push(result[i]["MARKET_AREA_NAME"]);
    storeV.push(result[i]["Store_Volume"]);
    store.push(result[i]["STORE_NBR"]);


}

bUnit = bUnit.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
division = division.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
region = region.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
market = market.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
store = store.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
  storeV = storeV.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })

             bUnit.sort();
            division.sort();
            region.sort();
            market.sort(function(a, b){return a - b});
            store.sort(function(a, b){return a - b});
             storeV.sort();

res.send({bUnit,division,region,market,store,storeV});




 });


app.get('/changeJobVal',function(req,res){
    var jobc1 = req.query.jobc;
    var job1=req.query.job;
    var filter = req.query.filter;
    var data;
    var jobc=[];
    var job=[];
 
    if(filter=="JOB_CODE"){
        data=jobc1;
    }else if(filter=="Job_Family"){
        data=job1;
    }
    if(data != undefined && data.length != 0){
        var len = data.length;
    }
   
    for (var i = 0; i < jobData.length; i++){
        var fil = jobData[i][filter];
        for (var k = 0; k < len; k++){
            if (fil == data[k]){
                jobc.push(jobData[i].JOB_CODE);
                job.push(jobData[i].Job_Family);
                
            }
        }
    }
    jobc = jobc.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
    job = job.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })

 jobc.sort();
 job.sort();
 
    res.send({jobc,job});
});

app.get('/clearJobVal',function(req,res){
 var jobc1 = req.query.jobc;
 var job1=req.query.job;
 var filter = req.query.filter;
 var data;
 var jobc=[];
 var job=[];
 var grade=[];

 var glen;
if(jobc1 != undefined && jobc1 !=""){
  glen = jobc1.length;
}else{
  glen =1;
  var gdata=[];
  gdata.push("");
  jobc1 = gdata;
}
var jlen;
if(job1 != undefined && job1 !=""){
  jlen = job1.length;
}else{
  jlen =1;
  var jdata=[];
  jdata.push("");
  job1 = jdata;
}




for (var i = 0; i < jobData.length; i++){
  if(filter=="Job_Family"){
   jobc.push(jobData[i].JOB_CODE);
   job.push(jobData[i].Job_Family);
   
 }else if(filter=="JOB_CODE"){

  for(var k=0; k< jlen; k++){
    if(job1[k] ==jobData[i].Job_Family){
     jobc.push(jobData[i].JOB_CODE);
     job.push(jobData[i].Job_Family);
   }else if(job1[k] == ""){
    jobc.push(jobData[i].JOB_CODE);
    job.push(jobData[i].Job_Family);
  }
}

}
}

for(var i = 0; i < gradeData.length; i++) {
    grade.push(gradeData[i].GRADE_LEVEL_GRP);
}

jobc = jobc.filter(function(elem, index, self) {
  return index == self.indexOf(elem);
})
job = job.filter(function(elem, index, self) {
  return index == self.indexOf(elem);
})

job.sort();
jobc.sort();
grade.sort();

res.send({jobc,job,grade});
});

app.get('/clearVal',function(req,res){
   var bUnit1 = req.query.bUnit;
    var division1=req.query.division;
    var region1 =req.query.region;
    var market1 =req.query.market;
    var store1 =req.query.store;
    var filter = req.query.filter;
    var storeV1 = req.query.storeV;
    var bUnit=[];
    var division=[];
    var region =[];
    var market =[];
    var store =[];
    var storeV=[];
    var filters={};


    if(bUnit1 != undefined && bUnit1 !="" && filter !="BUSINESS_UNIT"){

        filters["BUSINESS_UNIT"] = bUnit1;

    }

    if(division1 != undefined && division1!=""&& filter !="Division" && filter !="BUSINESS_UNIT"){

         filters["Division"] = division1;
    }

    if(region1 != undefined && region1 !=""&& filter !="REGION_NAME" && filter !="Division" && filter !="BUSINESS_UNIT"){

        filters["REGION_NAME"] = region1;
        
    }


    if(market1 != undefined  && market1 !=""&& filter !="MARKET_AREA_NAME" && filter !="REGION_NAME" && filter !="Division" && filter !="BUSINESS_UNIT"){

        market1= market1.map(Number);
        filters["MARKET_AREA_NAME"] = market1;
    }


    if(storeV1 != undefined  && storeV1 !=""&& filter !="Store_Volume" && filter !="MARKET_AREA_NAME" && filter !="REGION_NAME" && filter !="Division" && filter !="BUSINESS_UNIT"){

        filters["Store_Volume"] = storeV1;
      }


    if(store1 != undefined && store1 !=""&& filter !="STORE_NBR" && filter !="Store_Volume" && filter !="MARKET_AREA_NAME" && filter !="REGION_NAME" && filter !="Division" && filter !="BUSINESS_UNIT"){
        store1= store1.map(Number);
        filters["STORE_NBR"] = store1;
    }
    
    var datafilters = userfilters();

 var result = segData.filter(function (o) {
        return Object.keys(filters).every(function (k) {
            return filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

    result = result.filter(function (o) {
        return Object.keys(datafilters).every(function (k) {
            return datafilters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });
for(var i=0; i < result.length; i++){

    bUnit.push(result[i]["BUSINESS_UNIT"]);
    division.push(result[i]["Division"]);
    region.push(result[i]["REGION_NAME"]);
    market.push(result[i]["MARKET_AREA_NAME"]);
    storeV.push(result[i]["Store_Volume"]);
    store.push(result[i]["STORE_NBR"]);


}

bUnit = bUnit.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
division = division.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
region = region.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
market = market.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
store = store.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
storeV = storeV.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
})

            bUnit.sort();
            division.sort();
            region.sort();
            market.sort(function(a, b){return a - b});
            store.sort(function(a, b){return a - b});
             storeV.sort();

res.send({bUnit,division,region,market,store,storeV});

});

app.get('/getActDate',function(req,res){

 var compprd = req.query.compPrd;
 var timeframe = req.query.timeframe;
var filters={};
    if(compprd=="Year"){
          filters["PPE_WEIGHT"] = [3];
          filters["flag"] = [1];
          filters["FY_YR"] = timeframe.map(Number);
    }
    if(compprd=="Quarter"){
          filters["PPE_WEIGHT"] = [2,3];
          filters["flag"] = [1];
          filters["FYQTR"] = timeframe;
    }
    if(compprd=="Period"){
         
          filters["flag"] = [1];
          filters["FYPP"] = timeframe;
    }
    var result = timeFrame.filter(function (o) {
        return Object.keys(filters).every(function (k) {
            return filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

res.send({result});

});

app.get('/getDate',function(req,res){
var datSE=[];
    var compprd = req.query.compPrd;
    var timeframe = req.query.timeframe;
var filters={};
    if(compprd=="Year"){
          filters["PPE_WEIGHT"] = [3];
          filters["flag"] = [1];
          filters["FY_YR"] = timeframe.map(Number);
    }
    if(compprd=="Quarter"){
          filters["PPE_WEIGHT"] = [2,3];
          filters["flag"] = [1];
          filters["FYQTR"] = (timeframe);
    }
    if(compprd=="Period"){
         
          filters["flag"] = [1];
          filters["FYPP"] = (timeframe);
    }
    var result = timeFrame.filter(function (o) {
        return Object.keys(filters).every(function (k) {
            return filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });
   
     for(var i=0; i < result.length; i++){

    datSE.push(result[i]["PPE"]);
    }

        if(datSE.length==2){  
        var d1 = datSE[0].split("/");
        var d2=datSE[1].split("/");
        d1=d1.map(Number);
        d2=d2.map(Number);
       var dateOne = new Date(d1[2], d1[0], d1[1]); 
       var dateTwo = new Date(d2[2], d2[0], d2[1]); 
       if (dateOne > dateTwo) {
            console.log("Date One is greather then Date Two.");
            var endDate=datSE[0];
            var startDate=datSE[1];
        }else {
            console.log("Date Two is greather then Date One.");
            var endDate=datSE[1];
            var startDate=datSE[0];
        }
    
res.send({endDate,startDate});
}else{
     var d1 = datSE[0];
res.send({d1});
}

});
app.get('/timeFrame',function(req,res){

    var year_filters={};
    var qtr_filters={};
    var p2p_filters={};
    year_filters["PPE_WEIGHT"] = [3];
    year_filters["flag"] = [1];
    qtr_filters["PPE_WEIGHT"] = [2,3];
    qtr_filters["flag"] = [1];
    p2p_filters["flag"] = [1];
    var yearVal=[];
    var qtr=[];
    var p2p=[];
    var p2p_1=[];
    var p2p_2=[];
    var p2p_3=[];
    var p2p_4=[];
    var qtr1=[];
    var p2p1=[];
    var p2p2=[];
    var p2p3=[];
    var p2p4=[];
   var result = timeFrame.filter(function (o) {
        return Object.keys(year_filters).every(function (k) {
            return year_filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

       var qtrresult = timeFrame.filter(function (o) {
        return Object.keys(qtr_filters).every(function (k) {
            return qtr_filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

     var p2presult = timeFrame.filter(function (o) {
        return Object.keys(p2p_filters).every(function (k) {
            return p2p_filters[k].some(function (f) {
                return o[k] === f;
            });
        });
    });

    for(var i=0; i < result.length; i++){

    yearVal.push(result[i]["FY_YR"]);
    }

    for(var i=0; i < qtrresult.length; i++){

    qtr.push(qtrresult[i]["FYQTR"]);
    }

    for(var i=0; i < p2presult.length; i++){

        if(p2presult[i]["FY_QTR"] == 1){

             p2p_1.push(p2presult[i]["FYPP"]);

        } else  if(p2presult[i]["FY_QTR"] == 2){

             p2p_2.push(p2presult[i]["FYPP"]);
        
        }else  if(p2presult[i]["FY_QTR"] == 3){

             p2p_3.push(p2presult[i]["FYPP"]);

        }else  if(p2presult[i]["FY_QTR"] == 4){

             p2p_4.push(p2presult[i]["FYPP"]);
        }

   
    }

    

yearVal = yearVal.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
qtr = qtr.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
p2p_1 = p2p_1.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
p2p_2 = p2p_2.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
p2p_3 = p2p_3.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
p2p_4 = p2p_4.filter(function(elem, index, self) {
    return index == self.indexOf(elem);
})
for(var i=0; i < yearVal.length; i++){
   
    for(var j=0; j < qtr.length; j++){
    if((qtr[j].toString()).includes(yearVal[i].toString())){
        var abc = yearVal[i];
       qtr1.push({[abc]:qtr[j]});
    }

}
}

for(var i=0; i < yearVal.length; i++){
   
    for(var j=0; j < p2p_1.length; j++){
   
    if((p2p_1[j].toString()).includes(yearVal[i].toString())){
        var abc = yearVal[i];
       p2p1.push({[abc]:p2p_1[j]});
    }

   }
   for(var k=0; k < p2p_2.length; k++){
   
    if((p2p_2[k].toString()).includes(yearVal[i].toString())){
        var abc = yearVal[i];
       p2p2.push({[abc]:p2p_2[k]});
    }

   }
   for(var l=0; l < p2p_3.length; l++){
   
    if((p2p_3[l].toString()).includes(yearVal[i].toString())){
        var abc = yearVal[i];
       p2p3.push({[abc]:p2p_3[l]});
    }

   }
   for(var m=0; m < p2p_4.length; m++){
   
    if((p2p_4[m].toString()).includes(yearVal[i].toString())){
        var abc = yearVal[i];
       p2p4.push({[abc]:p2p_4[m]});
    }

   }
}
console.log(p2p1);
 qtr1 = combineKeyData(qtr1);
 p2p1 = combineKeyData(p2p1);
 p2p2 = combineKeyData(p2p2);
 p2p3 = combineKeyData(p2p3);
 p2p4 = combineKeyData(p2p4);
function combineKeyData(data) {
    var output = {}, item;
    for (var i = 0; i < data.length; i++) {
        item = data[i];
        for (var prop in item) {
            if (item.hasOwnProperty(prop)) {
                if (!(prop in output)) {
                    output[prop] = [];
                }
                output[prop].push(item[prop]);
            }
        }
    }
    return output;
    }    





yearVal.sort(function(a, b){return a - b});

 res.send({yearVal,qtr1,p2p1,p2p2,p2p3,p2p4});
});

app.get('/datadownload',function(req,res){

res.send({downData});
 });


 app.use(authChecker);
app.get('/getName',function(req,res){
console.log(decodedToken);

console.log("name is : ",uName);

var abc=uName;
var cde =userID;

 res.send({abc,cde});
});
app.listen(8443,function(){

    console.log("Webapp is listening in port 8443");


})